<?php
require 'db_connection.php'; // Database connection

// Fetch students awaiting approval
$result = $conn->query("SELECT * FROM students WHERE is_approved = 0");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['approve'])) {
    $student_id = $_POST['student_id'];
    // Approve the student
    $conn->query("UPDATE students SET is_approved = 1 WHERE student_id = $student_id");
    echo "<script>alert('Student approved successfully!'); window.location.href='manage_students.php';</script>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Pending Student Registrations</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Roll Number</th>
                    <th>Branch</th>
                    <th>Approve</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['student_id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['roll_number']; ?></td>
                    <td><?php echo $row['branch']; ?></td>
                    <td>
                        <form method="post" action="manage_students.php">
                            <input type="hidden" name="student_id" value="<?php echo $row['student_id']; ?>">
                            <button type="submit" name="approve" class="btn btn-success">Approve</button>
                        </form>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
