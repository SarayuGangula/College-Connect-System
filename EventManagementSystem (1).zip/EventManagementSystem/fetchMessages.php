<?php
session_start();
require 'db_connection.php';

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(["status" => "error", "message" => "Admin not logged in"]);
    exit;
}

$studentId = isset($_GET['studentId']) ? $_GET['studentId'] : null;
$adminId = $_SESSION['admin_id'];

if (!$studentId) {
    echo json_encode(["status" => "error", "message" => "Student ID is missing"]);
    exit;
}

$query = "SELECT messages.*, IF(messages.sender_id = ?, 'Admin', students.name) as sender_name
          FROM messages
          LEFT JOIN students ON students.student_id = messages.sender_id
          WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
          ORDER BY timestamp ASC";

$stmt = $conn->prepare($query);
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Failed to prepare statement"]);
    exit;
}

$stmt->bind_param("iiiii", $adminId, $adminId, $studentId, $studentId, $adminId);
if (!$stmt->execute()) {
    echo json_encode(["status" => "error", "message" => $stmt->error]);
    exit;
}

$result = $stmt->get_result();
$messages = $result->fetch_all(MYSQLI_ASSOC);
echo json_encode(["status" => "success", "data" => $messages]);

$stmt->close();
$conn->close();
?>