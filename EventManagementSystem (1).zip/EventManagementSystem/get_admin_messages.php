<?php
session_start();
require 'db_connection.php';

// Modify the query to join with the admins table
$query = "SELECT m.sender_id, a.username AS sender_name, m.message_text, m.timestamp 
          FROM messages m
          JOIN admin a ON m.sender_id = a.admin_id
          WHERE m.user_type_sender = 'admin'
          ORDER BY m.timestamp ASC";

$result = $conn->query($query);

$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = [
        'sender_id' => $row['sender_id'],
        'sender_name' => $row['sender_name'], // Fetch the sender's name
        'message_text' => $row['message_text'],
        'timestamp' => $row['timestamp']
    ];
}

echo json_encode($messages);  // Return the messages as JSON

$conn->close();
?>
