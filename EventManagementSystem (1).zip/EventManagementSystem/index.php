<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Event Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #eaeaea; /* Light gray background */
        }

        .header {
            background-color: #0056b3; /* A slightly darker blue for better contrast */
            color: #ffffff; /* Crisp white text */
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            text-shadow: 1px 1px 2px #000; /* Text shadow for better visibility */
        }

        .header img {
            width: 100px; /* Adjust as needed */
        }

        .header a {
            margin-left: 15px;
            padding: 10px 20px;
            color: white;
            text-decoration: none;
            border-radius: 25px;
            background: linear-gradient(90deg, #ff6a00, #ee0979); /* Vibrant button gradient */
            transition: background 0.3s, transform 0.3s;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Button shadow for depth */
        }

        .header a:hover {
            background: linear-gradient(90deg, #ee0979, #ff6a00); /* Reverse gradient on hover */
            transform: scale(1.05);
        }

        .hero-image {
            width: 100%;
            height: 50vh; /* Set height for hero section */
            background-image: url('images/college-image.gif'); /* Replace with your animated image path */
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            position: relative;
            margin-bottom: 30px;
        }

        .hero-overlay {
            background: rgba(0, 0, 0, 0.5); /* Darker semi-transparent background for contrast */
            padding: 20px;
            text-align: center;
            border-radius: 10px;
        }

        footer {
            text-align: center;
            padding: 20px;
            background-color: #0056b3; /* Match header color */
            color: white;
            position: relative;
            width: 100%;
        }

        .footer-links {
            margin: 10px 0;
        }

        .footer-links a {
            color: white;
            margin: 0 10px;
            text-decoration: none;
        }

        .about-card {
            margin-top: 30px;
            transition: transform 0.3s;
        }

        .about-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .about-us {
            margin-top: 20px;
        }

        h1, h2 {
            color: #ff6a00; /* Heading color matching button */
        }

        .btn-link {
            color: white;
            font-size: 1.25rem;
            margin-left: 15px;
        }
</style>


</head>
<body>
    <div class="header">
        <img src="images/logo.png" alt="College Logo" height="40px"> <!-- Replace with your logo path -->
        <div>
            <a href="admin_login.php" class="btn btn-link">Admin Login</a>
            <a href="student_login.php" class="btn btn-link">Student Login</a>
        </div>
    </div>

    <div class="hero-image">
        <div class="hero-overlay">
            <h1>Welcome to the College Event Management System</h1>
            <p>Empowering students to excel through innovation and collaboration.</p>
        </div>
    </div>

    <div class="container about-card">
        <div class="card">
            <img src="images/college-photo.jpg" class="card-img-top" alt="College Photo"> <!-- Replace with your college photo path -->
            <div class="card-body">
                <h5 class="card-title">About Our College</h5>
                <p class="card-text">Welcome to our college, a place of excellence and innovation. We provide quality education and encourage our students to grow academically and personally.</p>
            </div>
        </div>
    </div>

    <div class="container about-us">
        <h2>About Us</h2>
        <p>Our college is dedicated to fostering an environment of learning and growth. We aim to empower our students with the skills and knowledge necessary to succeed in their future careers.</p>
    </div>

    
    <?php include 'footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
