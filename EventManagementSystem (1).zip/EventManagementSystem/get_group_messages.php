<?php
session_start();
require 'db_connection.php'; // Include your database connection

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(["status" => "error", "message" => "Admin not logged in"]);
    exit;
}

// Prepare SQL query to fetch group chat messages for admins
$query = "SELECT * FROM messages WHERE user_type_receiver = 'admin' AND user_type_sender = 'admin' ORDER BY timestamp ASC";
$result = $conn->query($query);

// Fetch messages
$messages = '';
while ($row = $result->fetch_assoc()) {
    $senderId = $row['sender_id'];

    // Fetch admin name based on sender ID
    $adminQuery = "SELECT username FROM admin WHERE admin_id = ?";
    $adminStmt = $conn->prepare($adminQuery);
    $adminStmt->bind_param("i", $senderId);
    $adminStmt->execute();
    $adminResult = $adminStmt->get_result();
    
    if ($adminResult->num_rows > 0) {
        $adminData = $adminResult->fetch_assoc();
        $senderName = htmlspecialchars($adminData['username'], ENT_QUOTES);
    } else {
        $senderName = "Unknown";
    }

    // Append messages with sender names
    $messages .= '<div class="message"><strong>' . $senderName . ':</strong> ' . htmlspecialchars($row['message_text']) . ' <span class="timestamp">' . htmlspecialchars($row['timestamp']) . '</span></div>';
}

echo $messages;

$conn->close();
?>
