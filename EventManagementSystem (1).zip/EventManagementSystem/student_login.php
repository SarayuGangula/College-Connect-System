<?php
session_start();
require 'db_connection.php'; 

function registerUser() {
    global $conn;
    $name = $_POST['name'];
    $age = $_POST['age'];
    $roll_number = $_POST['roll_number'];
    $dob = $_POST['dob'];
    $mobile_number = $_POST['mobile_number'];
    $branch = $_POST['branch'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); 
    
    $stmt = $conn->prepare("INSERT INTO students (name, age, roll_number, dob, mobile_number, branch, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisssss", $name, $age, $roll_number, $dob, $mobile_number, $branch, $password);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "<script>alert('Registration successful! Pending admin approval.');</script>";
    } else {
        echo "<script>alert('Error in registration!');</script>";
    }
}

function loginUser() {
    global $conn;
    $roll_number = $_POST['roll_number'];
    $password = $_POST['password'];
    
    $stmt = $conn->prepare("SELECT * FROM students WHERE roll_number = ?");
    $stmt->bind_param("s", $roll_number);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();

        if ($student['approval_status'] == "Approved" && password_verify($password, $student['password'])) {
            $_SESSION['student_id'] = $student['student_id'];
            $_SESSION['roll_number'] = $student['roll_number'];
            $_SESSION['branch'] = $student['branch'];
            header("Location: events.php");
            exit();
        } else {
            echo "<script>alert('Invalid credentials or approval pending.');</script>";
        }
    } else {
        echo "<script>alert('Student not found!');</script>";
    }
}

// Handling POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['form_type']) && $_POST['form_type'] === 'login') {
        loginUser();
    } elseif (isset($_POST['form_type']) && $_POST['form_type'] === 'register') {
        registerUser();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Portal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: url('images/student_login_background.jpeg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 100%;
            max-width: 450px;
            background: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s;
        }

        .container:hover {
            transform: translateY(-5px);
        }

        .card-custom {
            border: none;
            margin: 0;
            padding: 0;
        }

        .card-header {
            background-color: #6c5ce7;
            color: white;
            padding: 15px;
            font-size: 24px;
            text-align: center;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .card-header:hover {
            background-color: #5a4cc1;
        }

        .form-section {
            display: none;
            opacity: 0;
            transition: opacity 0.5s ease;
        }

        .form-section.active {
            display: block;
            opacity: 1;
        }

        .form-group label {
            font-weight: 500;
            color: #333;
        }

        .btn-custom {
            background: linear-gradient(90deg, #6c5ce7, #a29bfe);
            border: none;
            color: white;
            padding: 12px;
            font-size: 18px;
            font-weight: bold;
            border-radius: 30px;
            transition: background 0.3s, box-shadow 0.3s;
        }

        .btn-custom:hover {
            box-shadow: 0 5px 15px rgba(163, 130, 255, 0.5);
        }

        .btn-secondary {
            background: transparent;
            border: 1px solid #6c5ce7;
            color: #6c5ce7;
            padding: 12px;
            font-size: 18px;
            font-weight: bold;
            border-radius: 30px;
            transition: background 0.3s, color 0.3s;
        }

        .btn-secondary:hover {
            background: #6c5ce7;
            color: white;
        }

        .form-control {
            border: 2px solid #ddd;
            transition: border-color 0.3s, box-shadow 0.3s;
            border-radius: 25px;
        }

        .form-control:focus {
            border-color: #6c5ce7;
            box-shadow: 0 0 5px rgba(108, 92, 231, 0.5);
        }

        .card-body {
            padding: 15px;
        }

        .text-center {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card card-custom">
            <div class="card-body">
                <!-- Login Form -->
                <form method="POST" action="" class="form-section active" id="login-form">
                <div class="card-header">Student Login Portal</div>
                    <input type="hidden" name="form_type" value="login">
                    <div class="form-group">
                        <label for="roll_number_login">Roll Number</label>
                        <input type="text" class="form-control" name="roll_number" id="roll_number_login" required>
                    </div>
                    <div class="form-group">
                        <label for="password_login">Password</label>
                        <input type="password" class="form-control" name="password" id="password_login" required>
                    </div>
                    <button type="submit" class="btn btn-custom btn-block">
                        <i class="fas fa-sign-in-alt"></i> Log In
                    </button>

                    <p class="text-center">or</p>
                    <p class="text-center">New User?</p>
                    <button type="button" class="btn btn-custom btn-block" id="signup-form-link">Sign Up</button>
                    <button type="button" class="btn btn-secondary btn-block" onclick="window.location.href='index.html';">Back</button>
                </form>
            </div>
            <div class="card-body">
               
                <!-- Registration Form -->
                <form method="post" action="" class="form-section" id="signup-form">
                     <!-- Registration Form Header -->
                <div class="card-header">Student Registration Portal</div>
                    <input type="hidden" name="form_type" value="register">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="age">Age</label>
                        <input type="number" class="form-control" id="age" name="age" required>
                    </div>
                    <div class="form-group">
                        <label for="roll_number">Roll Number</label>
                        <input type="text" class="form-control" id="roll_number" name="roll_number" required>
                    </div>
                    <div class="form-group">
                        <label for="dob">Date of Birth</label>
                        <input type="date" class="form-control" id="dob" name="dob" required>
                    </div>
                    <div class="form-group">
                        <label for="mobile_number">Mobile Number</label>
                        <input type="text" class="form-control" id="mobile_number" name="mobile_number" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="branch">Branch</label>
                        <select class="form-control" id="branch" name="branch" required>
                            <option value="Mechanical">Mechanical</option>
                            <option value="Information Technology">Information Technology</option>
                            <option value="Computer Science">Computer Science</option>
                            <option value="Civil">Civil</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-custom btn-block">
                        <i class="fas fa-user-plus"></i> Register
                    </button>
                    <button type="button" class="btn btn-secondary btn-block" onclick="window.location.href='student_login.php';">Back</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#signup-form-link').on('click', function() {
                $('#login-form').removeClass('active');
                $('#signup-form').addClass('active');
            });

            $('#login-form-link').on('click', function() {
                $('#signup-form').removeClass('active');
                $('#login-form').addClass('active');
            });
        });
    </script>
</body>
</html>
