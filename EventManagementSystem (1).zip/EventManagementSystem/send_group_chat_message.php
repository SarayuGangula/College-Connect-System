<?php
session_start();
require 'db_connection.php';

// Log the incoming POST data for debugging
error_log("Incoming POST data: " . print_r($_POST, true));

// Ensure required fields are present
if (!isset($_POST['message'], $_POST['branch'], $_POST['senderId'], $_POST['userType'])) {
    echo json_encode(["error" => "Invalid input!"]);
    exit();
}


// Sanitize inputs to avoid SQL injection and other potential issues
$messageText = trim($_POST['message']);
$branch = trim($_POST['branch']);
$senderId = (int)$_POST['senderId']; // Cast senderId to an integer for safety
$userTypeSender = $_POST['userType']; // This should be either 'admin' or 'student'

// Log sanitized values
error_log("Sanitized values - Sender ID: $senderId, Message: $messageText, Branch: $branch, User Type: $userTypeSender");

error_log("Message Text: '$messageText'"); // Log the message text for debugging

// Ensure that the message is not empty
if (empty($messageText)) {
    echo json_encode(["error" => "Message cannot be empty."]);
    exit();
}

// Fetch group_id based on branch
$query = "SELECT group_id FROM groups WHERE branch_name = ?";
$stmt = $conn->prepare($query);
if ($stmt === false) {
    echo json_encode(["error" => "Failed to prepare query for group fetching."]);
    exit();
}
$stmt->bind_param("s", $branch);
$stmt->execute();
$result = $stmt->get_result();
$group = $result->fetch_assoc();

if ($group) {
    $group_id = (int)$group['group_id']; // Ensure group_id is an integer

    // Insert message into the messages table
    $insertQuery = "INSERT INTO messages (sender_id, user_type_sender, group_id, message_text, timestamp) 
                    VALUES (?, ?, ?, ?, NOW())";
    $insertStmt = $conn->prepare($insertQuery);
    
    if ($insertStmt === false) {
        echo json_encode(["error" => "Failed to prepare message insert query."]);
        exit();
    }
    
    // Bind the parameters and execute the query
    $insertStmt->bind_param("isss", $senderId, $userTypeSender, $group_id, $messageText);
    
    if ($insertStmt->execute()) {
        echo json_encode(["success" => "Message sent successfully!"]);
    } else {
        echo json_encode(["error" => "Failed to send message: " . $conn->error]); // Log specific database error
    }
} else {
    echo json_encode(["error" => "No group found for this branch!"]);
}
?>
