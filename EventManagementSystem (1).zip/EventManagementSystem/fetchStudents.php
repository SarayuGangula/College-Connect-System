<?php
session_start(); // Start the session
require 'db_connection.php';  // Make sure this file contains the correct database connection setup

// Getting the branch from GET request
$branch = $_GET['branch'];

// Prepare and execute the SQL statement
$query = "SELECT `student_id`, `name` FROM `students` WHERE `branch` = ? AND `approval_status` = 'Approved'";
$stmt = $conn->prepare($query);

if (!$stmt) {~
    echo json_encode(['error' => 'Failed to prepare statement: ' . $conn->error]);
    exit;
}

$stmt->bind_param("s", $branch);
$status = $stmt->execute();

if (!$status) {
    echo json_encode(['error' => 'Failed to execute statement: ' . $stmt->error]);
    exit;
}

$result = $stmt->get_result();

// Fetch all students and encode into JSON format
$students = $result->fetch_all(MYSQLI_ASSOC);
echo json_encode($students);

// Close the statement and connection
$stmt->close();
$conn->close();
?>