<?php
    session_start();
    require 'db_connection.php'; // Database connection

    if (!isset($_SESSION['student_id'])) {
    header("Location: student_login.php");
    exit();
    }


    
    // Fetch student data
    $studentId = $_SESSION['student_id'];
    $query = "SELECT branch FROM students WHERE student_id = ?"; // Adjust the table and column names as necessary.
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $studentId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
    $student_data = $result->fetch_assoc();
    $_SESSION['student_branch'] = $student_data['branch'];
    } else {
    // Handle error: student not found
    echo "Student data not found. Please check the database!";
    exit();
    }
// Fetch admin data
$admins = [];
$adminQuery = "SELECT admin_id, username FROM admin WHERE branch = ?";
$adminStmt = $conn->prepare($adminQuery);
$adminStmt->bind_param("s", $_SESSION['student_branch']);
$adminStmt->execute();
$adminResult = $adminStmt->get_result();

if ($adminResult && $adminResult->num_rows > 0) {
    // Fetch each admin associated with the branch
    while ($admin = $adminResult->fetch_assoc()) {
        $admins[] = [
            'id' => $admin['admin_id'],
            'name' => htmlspecialchars($admin['username'], ENT_QUOTES)
        ];
    }
} else {
    echo "Admin not found for branch: " . $_SESSION['student_branch'];
}


function fetchEvents($conn, $branch = null, $status = 'all') {
    $query = "SELECT event_name, description, event_from_date as event_date, winners, branch, status, pic1, pic2, pic3 FROM events";
    // Prepare dynamic query based on selected branch and status
    $conditions = [];
    $params = [];
    $types = '';

    if ($branch) {
        $conditions[] = "branch = ?";
        $params[] = $branch;
        $types .= 's';
    }

    if ($status !== 'all') {
        $conditions[] = "status = ?";
        $params[] = $status;
        $types .= 's';
    }

    if ($conditions) {
        $query .= " WHERE " . implode(" AND ", $conditions);
    }

    $stmt = $conn->prepare($query);

    if ($types) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    return $stmt->get_result(); // Return the result set
}

    // Handle branch and status selection
    $selected_branch = isset($_POST['branch']) ? $_POST['branch'] : null;
    $selected_status = isset($_POST['status']) ? $_POST['status'] : 'all';

    // Fetch events based on selected branch and status
    $events = fetchEvents($conn, $selected_branch, $selected_status);

    // Fetch branches for the dropdown
    $branches = $conn->query("SELECT DISTINCT branch FROM events"); // Assuming branches are in the events table
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events and Chat</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <style>
  body {
    background-color: #f0f8ff; /* Light blue background */
}

.card {
    transition: transform 0.3s, box-shadow 0.3s; /* Smooth transition for card hover */
    border: none; /* No border for a cleaner look */
    margin-bottom: 30px; /* Increased spacing between cards */
    background-color: #ffffff; /* White background for cards */
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
    border-radius: 10px; /* Rounded corners */
}

/* Add hover effect for cards */
.card:hover {
    transform: translateY(-5px); /* Raise card on hover */
    box-shadow: 0 8px 40px rgba(0, 0, 0, 0.2); /* Deeper shadow on hover */
}

.card-header {
    font-size: 1.5rem; /* Larger font for event name */
    font-weight: bold;
    background-color: #007bff; /* Header background color */
    color: white; /* Header text color */
    padding: 10px; /* Padding for header */
    border-top-left-radius: 10px; /* Rounded corners */
    border-top-right-radius: 10px; /* Rounded corners */
}

.event-images {
    display: flex; /* Flexbox for images layout */
    gap: 10px; /* Space between images */
    justify-content: center; /* Center images */
}

.event-image {
    height: 150px; /* Adjust image height */
    width: auto; /* Maintain aspect ratio */
    border-radius: 5px; /* Rounded corners for images */
    object-fit: cover; /* Ensures the image covers the area without distortion */
}

/* Chat Popup Container */
.chat-popup {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 400px;
    max-width: 100%;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    z-index: 1000;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    animation: fadeIn 0.3s ease-in-out;
}

/* Animation for popup visibility */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Chat Header Styling */
.chat-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background-color: #007bff;
    color: #fff;
    border-bottom: 1px solid #ddd;
    position: relative; /* To position buttons absolutely */
}

/* Close and Minimize Button */
.close-button, .minimize-button {
    background: none;
    border: none;
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    position: absolute; /* Positioning them on top right */
    right: 10px; /* Space from the right */
}

.minimize-button {
    right: 40px; /* Positioning the minimize button slightly to the left of the close button */
}

.chat-header h1 {
    font-size: 1.125rem; /* Use rem for responsive text */
    margin: 0;
}

.close-button:hover, .minimize-button:hover {
    color: #ccc;
}

/* Messages Container */
.messages {
    padding: 10px;
    height: 300px;
    overflow-y: auto;
    flex-grow: 1;
    background-color: #f9f9f9;
    border-bottom: 1px solid #ddd;
}

/* Chat Input Field */
.chat-input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    margin: 10px;
    box-sizing: border-box;
}

/* Send Button */
#sendButton {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px;
    margin: 10px;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s; /* Smooth background transition */
}

#sendButton:hover {
    background-color: #0056b3; /* Darker blue on hover */
}

/* Focus state for buttons */
#sendButton:focus,
.close-button:focus,
.minimize-button:focus {
    outline: none; /* Remove default focus outline */
    box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.5); /* Add custom focus outline */
}

/* Responsive Layout */
@media (max-width: 500px) {
    .chat-popup {
        width: 90%;
    }
}

#header-events {
    background-color: #0056b3; /* A slightly darker blue for better contrast */
    color: #ffffff; /* crisp white text */
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    text-shadow: 1px 1px 2px #000; /* Adding a subtle shadow to text for better legibility */
}

    </style>
    
    </head>
    <body>
    <header class="d-flex justify-content-between align-items-center p-3 header" id="header-events">
    <img src="images/logo.png" alt="Logo" height="50"> <!-- Update with your logo path -->
    <form method="post" class="form-inline">
        <select name="branch" class="form-control mr-2" onchange="this.form.submit()">
            <option value="">Select Branch</option>
            <?php while ($branch = $branches->fetch_assoc()): ?>
                <option value="<?php echo htmlspecialchars($branch['branch']); ?>" <?php echo ($branch['branch'] == $selected_branch) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($branch['branch']); ?>
                </option>
            <?php endwhile; ?>
        </select>
    </form>
    <?php foreach ($admins as $admin): ?>
        <button class="btn" style="background: linear-gradient(90deg, #ff6a00, #ee0979); color: white; border-radius: 25px; padding: 10px 20px; border: none; margin-left: 10px; transition: background 0.3s, transform 0.3s;" 
                onclick="chatWithAdmin({ id: <?php echo $admin['id']; ?>, name: '<?php echo $admin['name']; ?>' })">
            Chat with <?php echo $admin['name']; ?>
        </button>
    <?php endforeach; ?>

    
    <button class="btn" style="background: linear-gradient(90deg, #ff6a00, #ee0979); color: white; border-radius: 25px; padding: 10px 20px; border: none; margin-left: 10px;"
    onclick="openGroupChatPopup('<?php echo $_SESSION['student_branch']; ?>')">
    Chat with <?php echo $_SESSION['student_branch']; ?> Group
</button>

    <button style="background: #dc3545; color: white; border-radius: 25px; padding: 10px 20px; border: none; transition: background 0.3s, transform 0.3s;">
        <a href="logout.php" style="color: white; text-decoration: none;">Logout</a>
    </button>
</header>





    <main>
        <form method="POST" action="">
            <input type="hidden" name="branch" value="<?php echo htmlspecialchars($selected_branch); ?>">
            <button name="status" value="upcoming" class="btn btn-info">Upcoming Events</button>
            <button name="status" value="ongoing" class="btn btn-warning">Ongoing Events</button>
            <button name="status" value="completed" class="btn btn-success">Completed Events</button>
            <button name="status" value="all" class="btn btn-secondary">All Events</button>
        </form>

        <section id="events">
            <div class="container mt-5">
                <h1 class="text-center">Events</h1>
                <div class="row">
    <?php
    // Loop through the fetched events
    while ($event = $events->fetch_assoc()) {
        $eventImages = [];
        for ($i = 1; $i <= 3; $i++) {
            if (!empty($event["pic$i"])) {
                $eventImages[] = 'data:image/jpeg;base64,' . base64_encode($event["pic$i"]);
            }
        }
        ?>
        <div class="col-md-6"> <!-- Adjusted to fit two cards per row -->
            <div class="card">
                <div class="card-body">
                    <h5 class="card-header"><?php echo htmlspecialchars($event['event_name']); ?></h5>
                    <p class="card-text"><strong>Description:</strong> <?php echo htmlspecialchars($event['description']); ?></p>
                    <p class="card-text"><strong>Date:</strong> <?php echo htmlspecialchars($event['event_date']); ?></p>
                    <p class="card-text"><strong>Winners:</strong> <?php echo htmlspecialchars($event['winners']); ?></p>
                    <p class="card-text"><strong>Status:</strong> <?php echo htmlspecialchars($event['status']); ?></p>
                    <p class="card-text"><strong>Branch:</strong> <?php echo htmlspecialchars($event['branch']); ?></p>
                    <div class="event-images">
                        <?php foreach ($eventImages as $image): ?>
                            <img src="<?php echo $image; ?>" alt="<?php echo htmlspecialchars($event['event_name']); ?>" class="event-image">
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    ?>
</div>

            </div>
        </section>
    </main>
    </main>

    <div id="chatPopup" class="chat-popup" style="display: none;">
    <div class="chat-header">
        <h1 id="adminName">Chat with Student</h1> <!-- Placeholder for student name -->
        <button class="close-button" onclick="closeChatPopup()">×</button>
        <button class="minimize-button" onclick="toggleChatPopup()">-</button>
    </div>
    <div id="messages" class="messages"></div>
    <form id="chatForm" action="javascript:void(0);" method="POST" onsubmit="return sendMessage();">
        <input type="text" id="chatMessage" name="message" placeholder="Type message..." class="chat-input" required>
        <input type="hidden" name="adminId" id="receiverId">
        <button type="button" id="sendButton">Send</button>
    </form>
    </div>
    
    <div id="groupChatPopup" class="chat-popup" style="display: none;">
    <div class="chat-header">
        <h1 id="groupChatTitle">Group Chat</h1> <!-- Title for the group chat -->
        <button class="close-button" onclick="closeGroupChatPopup()">×</button>
        <button class="minimize-button" onclick="toggleGroupChatPopup()">-</button>
    </div>
    <div id="groupMessages" class="messages"></div>

    <!-- Hidden input for group ID -->
    <input type="hidden" id="groupId" value="">

    <form id="groupChatForm" action="javascript:void(0);" method="POST" onsubmit="return sendGroupMessage();">
    <input type="text" id="groupChatMessage" name="message" placeholder="Type message..." class="chat-input" required>
        <input type="hidden" name="branch" id="branchName" value="<?php echo $_SESSION['student_branch']; ?>"> <!-- Store branch from session -->
        <input type="hidden" name="studentId" id="studentId" value="<?php echo $_SESSION['student_id']; ?>"> <!-- Store student ID from session -->
        <button type="button" id="groupSendButton">Send</button>
    </form>
</div>




    <?php include 'footer.php'; ?>


    <script>

var messagePollingInterval; // To store the polling interval ID

function loadMessages(receiverId) {
    console.log("Loading messages for receiver ID: " + receiverId);

    $.ajax({
        url: 'get_messages_student.php', // Use the new PHP script for students
        type: 'POST',
        data: {
            receiver_id: receiverId // Only send the receiver ID
        },
        success: function(data) {
            $('#messages').html(data); // Display the fetched messages
            scrollToBottom(); // Scroll to the bottom to show the latest messages
        },
        error: function(xhr, status, error) {
            console.error("Failed to load messages: " + status + ", " + error);
        }
    });
}
function makePopupDraggable(popup) {
    var posX = 0, posY = 0, mouseX = 0, mouseY = 0;
    var header = popup.querySelector('.chat-header');

    header.onmousedown = function(e) {
        e.preventDefault();
        // Get the current mouse cursor position
        mouseX = e.clientX;
        mouseY = e.clientY;

        // Call function when the mouse moves
        document.onmousemove = function(e) {
            e.preventDefault();

            // Calculate the new cursor position
            posX = mouseX - e.clientX;
            posY = mouseY - e.clientY;
            mouseX = e.clientX;
            mouseY = e.clientY;

            // Set the popup's new position
            popup.style.top = (popup.offsetTop - posY) + "px";
            popup.style.left = (popup.offsetLeft - posX) + "px";
        };

        // Stop moving the popup when mouse is released
        document.onmouseup = function() {
            document.onmousemove = null;
            document.onmouseup = null;
        };
    };
}

function openChatPopup(adminId, adminName) {
    $('#receiverId').val(adminId); // Set the admin ID in the hidden input field
    $('#adminName').text('Chat with ' + adminName); // Set the admin name in the header

    // AJAX call to fetch messages for the specific admin
    loadMessages(adminId); // Load initial messages
    $('#chatPopup').fadeIn(); // Smoothly show the popup

    // Start polling for new messages every 5 seconds (5000 ms)
    clearInterval(messagePollingInterval); // Clear any existing interval
    messagePollingInterval = setInterval(function() {
        loadMessages(adminId); // Poll for new messages
    }, 5000);
    var popup = document.querySelector('.chat-popup');
            makePopupDraggable(popup);
}

// Add a function to close the chat popup
function closeChatPopup() {
    $('#chatPopup').fadeOut(); // Hide the popup
    clearInterval(messagePollingInterval); // Clear the polling interval when closing the popup
}

// Example of calling openChatPopup when an admin is selected
function chatWithAdmin(selectedAdmin) {
    const adminId = selectedAdmin.id; // Get admin ID from the selected admin object
    const adminName = selectedAdmin.name; // Get admin name from the selected admin object
    openChatPopup(adminId, adminName); // Open the chat popup with the admin's details
}



// Change the button to trigger the sendMessage function directly
document.getElementById("sendButton").addEventListener("click", function() {
    sendMessage();
});

document.getElementById("chatMessage").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        event.preventDefault(); // Prevent new line
        sendMessage(); // Trigger the sendMessage function
    }
});

// Ensure the function is not declared twice
function closeChatPopup() {
    $('#chatPopup').fadeOut(); // Smoothly hide the popup
    clearInterval(messagePollingInterval); // Clear the polling interval when closing the popup
}

// Your existing sendMessage function
function sendMessage() {
    var chatMessage = $('#chatMessage').val();
    var adminId = $('#receiverId').val();
    var studentId = <?php echo json_encode($_SESSION['student_id']); ?>; // Ensure this is defined

    if (!chatMessage.trim()) {
        alert("Please type a message.");
        return; // Stop function execution if no message
    }

    // AJAX request to sendMessages.php
    $.ajax({
        type: "POST",
        url: "student_send_message.php",
        data: {
            message: chatMessage,
            adminId: adminId, // Ensure you're sending the admin ID as well
            studentId: studentId // Send the student ID as part of your payload
        },
        success: function(response) {
            var result = JSON.parse(response);
            if (result.status === 'success') {
                // Append message to chat window
                $('#messages').append('<div class="message sent">' + chatMessage + '</div>');
                $('#chatMessage').val(''); // Clear input field after sending
                scrollToBottom(); // Scroll to show new message
            } else {
                alert('Failed to send message. Please try again.');
            }
        },
        error: function() {
            alert('Error sending message. Please try again later.');
        }
    });
}



    function scrollToBottom() {
    var messages = document.getElementById('messages');
    messages.scrollTop = messages.scrollHeight;
    }


    function toggleChatPopup() {
    var popup = document.getElementById('chatPopup');
    var messages = document.getElementById('messages');
    if (popup.style.height === "40px") {
        popup.style.height = "auto"; // Expand
        messages.style.display = "block"; // Show content
    } else {
        popup.style.height = "40px"; // Collapse to a smaller size
        messages.style.display = "none"; // Hide content
    }
    }

    function closeChatPopup() {
    $('#chatPopup').fadeOut(); // Smoothly hide the popup
    console.log("Chat popup closed");
    }




    
var groupMessagePollingInterval;

// Function to open the group chat popup
function openGroupChatPopup(branchName) {
    // Fetch group ID based on the branch name
    $.ajax({
        url: 'get_group_id.php', // This should return the group_id for the branch
        type: 'POST',
        data: { branch: branchName },
        success: function(data) {
            var groupId = JSON.parse(data).group_id;
            $('#groupId').val(groupId); // Set the group ID in the hidden input
            $('#groupChatTitle').text('Group Chat for ' + branchName);

            // Load the messages initially for this group
            loadGroupMessages(groupId); // Call load messages with groupId

            // Start polling for new messages
            startPollingForMessages(groupId); // Start the polling after opening the chat

            // Show the popup
            $('#groupChatPopup').fadeIn();
        },
        error: function(xhr, status, error) {
            console.error("Failed to get group ID: " + status + ", " + error);
        }
    });
}

// Polling function to fetch new messages at a regular interval
function startPollingForMessages(groupId) {
    // Clear any existing polling interval to avoid multiple intervals running
    clearInterval(groupMessagePollingInterval);
    
    // Set polling interval to fetch new messages every 5 seconds (5000 ms)
    groupMessagePollingInterval = setInterval(() => {
        loadGroupMessages(groupId); // Fetch messages for the group
    }, 5000);
}

// Function to close the group chat popup
function closeGroupChatPopup() {
    $('#groupChatPopup').fadeOut();
    clearInterval(groupMessagePollingInterval); // Stop polling when chat is closed
}

// Function to load group messages
function loadGroupMessages() {
    const groupIdElement = document.getElementById('groupId');
    if (!groupIdElement) {
        console.error("Element with ID 'groupId' not found.");
        return;
    }
    
    const groupId = groupIdElement.value; // Get the group ID from hidden input

    fetch('get_group_chat_messages.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ 'group_id': groupId })
    })
    .then(response => response.json())
    .then(data => {
        const messageContainer = document.getElementById('groupMessages');
        messageContainer.innerHTML = ''; // Clear previous messages

        if (Array.isArray(data) && data.length) {
            data.forEach(msg => {
                const messageElement = document.createElement('p');
                messageElement.innerHTML = `<strong>${msg.sender}:</strong> ${msg.message} <small>${msg.timestamp}</small>`;
                messageContainer.appendChild(messageElement);
            });
        } else {
            messageContainer.innerHTML = '<p>No messages yet.</p>';
        }
    })
    .catch(error => console.error('Error loading messages:', error));
}

function sendGroupMessage() {
    const messageInput = document.getElementById('groupChatMessage');
    const message = messageInput.value.trim(); // Get the message input value

    if (!message) {
        console.error('Message is empty'); // Log if the message is empty
        return; // Don't send empty messages
    }

    console.log("Message to be sent:", message); // Log the message being sent

    const groupId = document.getElementById('groupId').value; // Get group ID
    const studentId = document.getElementById('studentId').value; // Get student ID
    const branchName = document.getElementById('branchName').value; // Get branch name

    const userTypeSender = 'student'; // Assuming user type sender is "student"

    // Send message to the server
    fetch('send_group_chat_message.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ 
            group_id: groupId, 
            message: message, 
            senderId: studentId, // Adjust this to use the correct ID for the sender
            branch: branchName, 
            userType: userTypeSender // Include user type
        })
    })
    
    .then(response => response.json())
    .then(data => {
        console.log("Response from server:", data); // Log the response from the server
        if (data.success) {
            messageInput.value = ''; // Clear the input field
            loadGroupMessages(groupId); // Reload messages to include the new one
        } else {
            console.error('Failed to send message:', data.error);
        }
    })
    .catch(error => console.error('Error sending message:', error));

    return false; // Prevent the form from submitting
}




// Call this to load messages after DOM content is loaded
document.addEventListener('DOMContentLoaded', loadGroupMessages);

// Event listener for sending messages on Enter key press
document.getElementById('groupChatMessage').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        event.preventDefault(); // Prevent default form submission
        sendGroupMessage(); // Call the function to send the message
    }
});



function toggleGroupChatPopup() {
    var popup = document.getElementById('groupChatPopup');
    var messages = document.getElementById('groupMessages');

    // Toggle between minimized and expanded states
    if (popup.classList.contains("minimized")) {
        popup.classList.remove("minimized");
        popup.style.height = "400px"; // Set to desired expanded height
        messages.style.display = "block"; // Show chat messages when expanded
    } else {
        popup.classList.add("minimized");
        popup.style.height = "40px"; // Set to minimized height
        messages.style.display = "none"; // Hide chat messages when minimized
    }
}


        </script>


    </body>
    </html>
