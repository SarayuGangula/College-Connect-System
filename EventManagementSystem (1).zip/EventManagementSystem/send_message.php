<?php
session_start();
require 'db_connection.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id'];
    $message_text = $_POST['message_text'];
    $sender_id = $_SESSION['admin_id']; // Get admin ID from session
    $receiver_id = $student_id;

    // Get sender and receiver names
    $sender_query = $conn->prepare("SELECT username FROM admin WHERE admin_id = ?");
    $sender_query->bind_param("i", $sender_id);
    $sender_query->execute();
    $sender_result = $sender_query->get_result();
    $sender_name = $sender_result->fetch_assoc()['username'];

    $receiver_query = $conn->prepare("SELECT name FROM students WHERE student_id = ?");
    $receiver_query->bind_param("i", $receiver_id);
    $receiver_query->execute();
    $receiver_result = $receiver_query->get_result();
    $receiver_name = $receiver_result->fetch_assoc()['name'];

    // Insert the message
    $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message_text, receiver_branch) VALUES (?, ?, ?, ?)");
    $branch = $_SESSION['branch']; // Assuming branch is also stored in session
    $stmt->bind_param("iiss", $sender_id, $receiver_id, $message_text, $branch);
    $stmt->execute();

    // Return the sender's name for display purposes
    echo json_encode(['sender_name' => $sender_name, 'message_text' => $message_text]);
}
?>
