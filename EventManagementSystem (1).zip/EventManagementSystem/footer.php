<!DOCTYPE html>
<html lang="en">
<head>
    <title>Footer Design</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        /* Ensure the body takes up the full viewport height */
        html, body {
            height: 100%;
            margin: 0;
            font-family: 'Poppins', sans-serif;
        }

        /* The container takes the full height, allowing the footer to stay at the bottom */
        .container {
            min-height: 100vh; /* Take full viewport height */
            display: flex;
            flex-direction: column;
        }

        /* The main content area should take up remaining space */
        .main-content {
            flex: 1; /* This pushes the footer down */
        }

         /* Footer styling */
		 footer {
            background-color: #000000; /* Changed to black */
            text-align: center;
            padding: 0.5rem 0; /* Reduced padding for less height */
            width: 100%; /* Ensure the footer spans the full width */
        }

        .footer h4 {
            font-size: 16px; /* Reduced font size */
            color: #ffffff;
            margin-top: 25px; /* Added more top margin */
            margin-bottom: 15px; /* Reduced bottom margin */
            font-weight: 500;
        }

        .social-links {
            margin-bottom: 10px; /* Reduced bottom margin */
        }

        .social-links a {
            display: inline-block;
            height: 30px; /* Reduced height for icons */
            width: 30px; /* Reduced width for icons */
            background-color: rgba(255, 255, 255, 0.2);
            margin: 0 8px; /* Slightly reduced margin */
            text-align: center;
            line-height: 30px;
            border-radius: 50%;
            color: #ffffff;
            transition: all 0.5s ease;
        }

        .social-links a:hover {
            color: #24262b;
            background-color: #ffffff;
        }

        .footer p {
            color: #bbbbbb;
            margin-top: 10px; /* Reduced margin-top */
            margin-bottom: 0;
            font-size: 14px; /* Slightly reduced font size */
        }
    </style>
</head>
<body>
    <footer class="footer">
        <h4>Follow Us</h4>
        <div class="social-links">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-linkedin-in"></i></a>
        </div>
        <p>© 2024 Your Company Name. All rights reserved.</p>
    </footer>
</div>

</body>
</html>
