<?php
session_start();
require 'db_connection.php'; // Make sure this is the correct path to your DB connection file

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(["status" => "error", "message" => "Admin not logged in"]);
    exit;
}

// Retrieve the student ID from POST request
$studentId = $_POST['student_id'] ?? null;

if (!$studentId) {
    echo json_encode(["status" => "error", "message" => "Student ID is missing"]);
    exit;
}

// Prepare the SQL query to retrieve messages
$query = "SELECT sender_id, message_text, timestamp FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY timestamp";
$stmt = $conn->prepare($query);
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Failed to prepare statement"]);
    exit;
}

$adminId = $_SESSION['admin_id'];
$stmt->bind_param("iiii", $adminId, $studentId, $studentId, $adminId);
$stmt->execute();
$result = $stmt->get_result();

// Initialize an empty array for messages
$messages = [];

// Fetch messages and format them
while ($row = $result->fetch_assoc()) {
    $message = [
        'sender_id' => $row['sender_id'],
        'message_text' => htmlspecialchars($row['message_text']),
        'timestamp' => $row['timestamp'],
    ];
    $messages[] = $message;
}

// Fetch the student's name using the student ID
$studentQuery = "SELECT name FROM students WHERE student_id = ?";
$studentStmt = $conn->prepare($studentQuery);
$studentStmt->bind_param("i", $studentId);
$studentStmt->execute();
$studentResult = $studentStmt->get_result();

$studentName = "";
if ($studentResult->num_rows > 0) {
    $studentData = $studentResult->fetch_assoc();
    $studentName = htmlspecialchars($studentData['name'], ENT_QUOTES);
}

// Output messages in a simple format
foreach ($messages as $message) {
    if ($message['sender_id'] == $adminId) {
        // Correctly labeling messages from the admin
        echo '<div><strong>Admin:</strong> ' . $message['message_text'] . ' <small>(' . $message['timestamp'] . ')</small></div>';
    } else {
        // Messages from the student show the student's name
        echo '<div><strong>' . $studentName . ':</strong> ' . $message['message_text'] . ' <small>(' . $message['timestamp'] . ')</small></div>';
    }
}

// Clean up
$stmt->close();
$studentStmt->close();
$conn->close();
?>
