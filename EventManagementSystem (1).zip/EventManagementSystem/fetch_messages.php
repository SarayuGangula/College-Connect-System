<?php
session_start();
require 'db_connection.php'; // Database connection

$student_id = $_GET['student_id'];
$admin_id = $_SESSION['admin_id']; // Assuming admin ID is stored in session

$query = "SELECT m.message_text, m.message_date, s.name AS student_name, a.username AS admin_name 
          FROM messages m 
          LEFT JOIN students s ON m.receiver_id = s.student_id 
          LEFT JOIN admin a ON m.sender_id = a.admin_id 
          WHERE (m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("iiii", $admin_id, $student_id, $student_id, $admin_id);
$stmt->execute();
$result = $stmt->get_result();

$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}

foreach ($messages as $message) {
    if ($message['admin_name']) {
        echo "<div><strong>Admin: </strong>{$message['admin_name']}: {$message['message_text']} <em>{$message['message_date']}</em></div>";
    } elseif ($message['student_name']) {
        echo "<div><strong>Student: </strong>{$message['student_name']}: {$message['message_text']} <em>{$message['message_date']}</em></div>";
    }
}
?>
