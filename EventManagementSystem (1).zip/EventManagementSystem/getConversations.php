<?php
session_start();
require 'db_connection.php';

// Fetch approved students from the database
$query = "SELECT `student_id`, `name`, `roll_number` FROM `students` WHERE `approval_status` = 'Approved'";
$result = $conn->query($query);

// Start the HTML output
echo '<h2>Registered Students</h2>';
echo '<table class="table">';
echo '<thead><tr><th>Student Name</th><th>Roll Number</th><th>Action</th></tr></thead>';
echo '<tbody>';

// Loop through each student and display their details
while ($student = $result->fetch_assoc()) {
    echo '<tr>';
    echo '<td>' . htmlspecialchars($student['name']) . '</td>';
    echo '<td>' . htmlspecialchars($student['roll_number']) . '</td>';
    echo '<td>';
    echo '<button type="button" class="btn btn-info" data-receiver-id="' . $student['student_id'] . '" data-student-name="' . htmlspecialchars($student['name'], ENT_QUOTES) . '" onclick="openChatPopup(this)">Chat</button>';
    echo '</td>';
    echo '</tr>';
}

// End the HTML output
echo '</tbody></table>';
$conn->close();
?>
