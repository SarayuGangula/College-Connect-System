<?php
session_start();
require 'db_connection.php'; // Include your database connection file

if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php');
    exit();
}

// Fetch the branch of the logged-in admin
$stmt = $conn->prepare("SELECT branch FROM admin WHERE username = ?");
$stmt->bind_param("s", $_SESSION['admin']);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$branch = $row['branch'];

// Fetch pending approvals for students in the same branch
$pending_query = $conn->prepare("SELECT * FROM students WHERE branch = ? AND approval_status = 'Pending'");
$pending_query->bind_param("s", $branch);
$pending_query->execute();
$pending_result = $pending_query->get_result();

// Fetch approved students for the branch
$approved_query = $conn->prepare("SELECT * FROM students WHERE branch = ? AND approval_status = 'Approved'");
$approved_query->bind_param("s", $branch);
$approved_query->execute();
$approved_result = $approved_query->get_result();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve_student'])) {
        $student_id = $_POST['student_id'];
        $stmt = $conn->prepare("UPDATE students SET approval_status = 'Approved' WHERE student_id = ?");
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
    } elseif (isset($_POST['reject_student'])) {
        $student_id = $_POST['student_id'];
        $stmt = $conn->prepare("UPDATE students SET approval_status = 'Rejected' WHERE student_id = ?");
        $stmt->bind_param("i", $student_id);
        $stmt->execute();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Approvals</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Pending Approvals for <?php echo $branch; ?> Branch</h2>
        <h3>Pending Students</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Roll Number</th>
                    <th>Mobile Number</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($student = $pending_result->fetch_assoc()) : ?>
                    <tr>
                        <td><?php echo $student['name']; ?></td>
                        <td><?php echo $student['roll_number']; ?></td>
                        <td><?php echo $student['mobile_number']; ?></td>
                        <td>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">
                                <button type="submit" name="approve_student" class="btn btn-success">Approve</button>
                            </form>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">
                                <button type="submit" name="reject_student" class="btn btn-danger">Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <h3>Approved Students</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Roll Number</th>
                    <th>Mobile Number</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($student = $approved_result->fetch_assoc()) : ?>
                    <tr>
                        <td><?php echo $student['name']; ?></td>
                        <td><?php echo $student['roll_number']; ?></td>
                        <td><?php echo $student['mobile_number']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
