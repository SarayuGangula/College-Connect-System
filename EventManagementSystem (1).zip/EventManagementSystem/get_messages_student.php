    <?php
    session_start();
    require 'db_connection.php'; // Include your database connection

    // Check if the student is logged in
    if (!isset($_SESSION['student_id'])) {
        echo json_encode(["status" => "error", "message" => "Student not logged in"]);
        exit;
    }

    // Get the receiver (admin) ID from the POST request
    $receiverId = $_POST['receiver_id'] ?? null; // Ensure this matches the data sent from AJAX
    $studentId = $_SESSION['student_id']; // Get the student ID from the session

    // Validate input
    if (!$receiverId) {
        echo json_encode(["status" => "error", "message" => "Receiver ID is missing"]);
        exit;
    }

    // Prepare SQL query to fetch messages
    $query = "SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY timestamp ASC";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Failed to prepare statement: " . $conn->error]);
        exit;
    }

    // Bind parameters and execute
    $stmt->bind_param("iiii", $studentId, $receiverId, $receiverId, $studentId);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch messages
    $messages = '';
    while ($row = $result->fetch_assoc()) {
        $senderId = $row['sender_id'];

        // Determine the sender's name
        if ($senderId === $studentId) {
            $senderName = "You"; // Display "You" for student messages
        } else {
            // Fetch admin name based on sender ID
            $adminQuery = "SELECT username FROM admin WHERE admin_id = ?";
            $adminStmt = $conn->prepare($adminQuery);
            $adminStmt->bind_param("i", $senderId);
            $adminStmt->execute();
            $adminResult = $adminStmt->get_result();
            
            if ($adminResult->num_rows > 0) {
                $adminData = $adminResult->fetch_assoc();
                $senderName = htmlspecialchars($adminData['username'], ENT_QUOTES);
            } else {
                $senderName = "Unknown"; // Fallback if the admin is not found
            }
        }

        // Append messages with sender names
        $messages .= '<div class="message"><strong>' . $senderName . ':</strong> ' . htmlspecialchars($row['message_text']) . ' <span class="timestamp">' . htmlspecialchars($row['timestamp']) . '</span></div>';
    }

    // Return messages
    echo $messages;

    // Clean up
    $stmt->close();
    $conn->close();
    ?>
