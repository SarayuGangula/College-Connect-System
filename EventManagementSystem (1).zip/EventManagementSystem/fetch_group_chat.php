<?php
include 'db_connection.php'; // Make sure to include your DB connection

$branch = $_POST['branch']; // Get branch from request
$student_id = $_POST['student_id']; // Get student ID

// Query to fetch messages
$sql = "SELECT * FROM messages WHERE (sender_id = ? AND user_type_sender = 'student') OR (receiver_id = ? AND user_type_receiver = 'admin') OR (receiver_id IN (SELECT student_id FROM students WHERE branch = ?)) ORDER BY timestamp ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iis", $student_id, $student_id, $branch);
$stmt->execute();
$result = $stmt->get_result();

$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}
echo json_encode($messages);
?>
