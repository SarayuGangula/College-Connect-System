<?php
require 'db_connection.php'; // Database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $roll_number = $_POST['roll_number'];
    $dob = $_POST['dob'];
    $mobile_number = $_POST['mobile_number'];
    $branch = $_POST['branch'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); 

    // Insert the student data into the 'students' table with approval pending
    $stmt = $conn->prepare("INSERT INTO students (name, age, roll_number, dob, mobile_number, branch, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisssss", $name, $age, $roll_number, $dob, $mobile_number, $branch, $password);
    $stmt->execute();
    if ($stmt->affected_rows > 0) {
        echo "<script>alert('Registration successful! Pending admin approval.');</script>";
    } else {
        echo "<script>alert('Error in registration!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .registration-form {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }
        h1 {
            font-size: 2rem;
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-control {
            border-radius: 5px;
        }
        .btn {
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            padding: 10px;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #218838;
        }
        .btn-block {
            width: 100%;
        }
        /* Add subtle hover effect for inputs */
        .form-control:focus {
            border-color: #28a745;
            box-shadow: 0 0 8px rgba(40, 167, 69, 0.25);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="registration-form">
            <h1>Student Registration</h1>
            <form method="post" action="student_register.php">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="age">Age</label>
                    <input type="number" class="form-control" id="age" name="age" required>
                </div>
                <div class="form-group">
                    <label for="roll_number">Roll Number</label>
                    <input type="text" class="form-control" id="roll_number" name="roll_number" required>
                </div>
                <div class="form-group">
                    <label for="dob">Date of Birth</label>
                    <input type="date" class="form-control" id="dob" name="dob" required>
                </div>
                <div class="form-group">
                    <label for="mobile_number">Mobile Number</label>
                    <input type="text" class="form-control" id="mobile_number" name="mobile_number" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="branch">Branch</label>
                    <select class="form-control" id="branch" name="branch" required>
                        <option value="Mechanical">Mechanical</option>
                        <option value="Information Technology">Information Technology</option>
                        <option value="Computer Science">Computer Science</option>
                        <option value="Civil">Civil</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-success btn-block">Register</button>
            </form>
        </div>
    </div>
</body>
</html>
