<?php
    session_start();
    require 'db_connection.php'; // Database connection

    if (!isset($_SESSION['admin_id'])) {
        header('Location: admin_login.php');
        exit();
    }

    // Fetch the branch of the logged-in admin
    $branch = $_SESSION['admin_branch'];
    if (isset($_SESSION['admin_username'])) {
        $adminName = $_SESSION['admin_username'];
    } else {
        // Handle case where username is not set, like redirecting to login
        header('Location: admin_login.php');
        exit();
    }



    // Fetch students in the same branch
    $students_query = $conn->prepare("SELECT * FROM students WHERE branch = ?");
    $students_query->bind_param("s", $branch);
    $students_query->execute();
    $students_result = $students_query->get_result();


    // Fetch pending approvals for students in the same branch
    $pending_approvals_query = $conn->prepare("SELECT * FROM students WHERE branch = ? AND approval_status = 'Pending'");
    $pending_approvals_query->bind_param("s", $branch);
    $pending_approvals_query->execute();
    $pending_approvals_result = $pending_approvals_query->get_result();

    // Fetch approved students for the same branch
    $approved_students_query = $conn->prepare("SELECT * FROM students WHERE branch = ? AND approval_status = 'Approved'");
    $approved_students_query->bind_param("s", $branch);
    $approved_students_query->execute();
    $approved_students_result = $approved_students_query->get_result();

    // Fetch rejected students for the same branch
    $rejected_students_query = $conn->prepare("SELECT * FROM students WHERE branch = ? AND approval_status = 'Rejected'");
    $rejected_students_query->bind_param("s", $branch);
    $rejected_students_query->execute();
    $rejected_students_result = $rejected_students_query->get_result();

    // Fetch events for the same branch
    $events_query = $conn->prepare("SELECT event_id, event_name, description, event_from_date, event_to_date,winners, pic1, pic2, pic3 FROM events WHERE branch = ? AND status != 'Cancelled'");
    $events_query->bind_param("s", $branch);
    $events_query->execute();
    $events_result = $events_query->get_result();
    
    
    // Handle form submissions for adding, modifying, and approving students/events
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['add_student'])) {
            $name = $_POST['student_name'];
            $age = $_POST['student_age'];
            $roll_number = $_POST['student_roll_number'];
            $dob = $_POST['student_dob'];
            $mobile_number = $_POST['student_mobile_number'];
            $password = password_hash($_POST['student_password'], PASSWORD_DEFAULT);
        
            $stmt = $conn->prepare("INSERT INTO students (name, age, roll_number, dob, mobile_number, branch, password, approval_status) VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')");
            $stmt->bind_param("sisssss", $name, $age, $roll_number, $dob, $mobile_number, $branch, $password);
            $stmt->execute();
            
            // Redirect to the same page with a success parameter
            header('Location: admin_dashboard.php?success=add_student&name=' . urlencode($name));
            exit();
        } elseif (isset($_POST['modify_student'])) {
            // Modify Student
            $student_id = $_POST['student_id'];
            $name = $_POST['student_name'];
            $age = $_POST['student_age'];
            $roll_number = $_POST['student_roll_number'];
            $dob = $_POST['student_dob'];
            $mobile_number = $_POST['student_mobile_number'];
            $stmt = $conn->prepare("UPDATE students SET name=?, age=?, roll_number=?, dob=?, mobile_number=? WHERE student_id=?");
            $stmt->bind_param("sisssi", $name, $age, $roll_number, $dob, $mobile_number, $student_id);
            $stmt->execute();
            
            header('Location: admin_dashboard.php?success=student_modified');
            exit();
        } elseif (isset($_POST['remove_student'])) {
            // Remove Student
            $student_id = $_POST['student_id'];
            $stmt = $conn->prepare("DELETE FROM students WHERE student_id=?");
            $stmt->bind_param("i", $student_id);
            $stmt->execute();
        } elseif (isset($_POST['approve_student'])) {
            // Approve Student
            $student_id = $_POST['student_id'];
            $stmt = $conn->prepare("UPDATE students SET approval_status='Approved' WHERE student_id=?");
            $stmt->bind_param("i", $student_id);
            $stmt->execute();
        } elseif (isset($_POST['reject_student'])) {
            // Reject Student
            $student_id = $_POST['student_id'];
            $stmt = $conn->prepare("UPDATE students SET approval_status='Rejected' WHERE student_id=?");
            $stmt->bind_param("i", $student_id);
            $stmt->execute();
        } elseif (isset($_POST['add_event'])) {
            

            // Retrieve event data from POST request
            $event_name = $_POST['event_name'];
            $description = $_POST['description'];
            $event_from_date = $_POST['event_from_date'];
            $event_to_date = $_POST['event_to_date'];
            $winners = $_POST['winners'] ?? ""; // Retrieve winners, default to empty if not provided
        
            // Use stored branch from the session
            $branch = $_SESSION['admin_branch'];  // Using existing session variable for branch
        
            // Determine the event status based on dates
            $current_date = date('Y-m-d');
            $status = 'Completed';
            if ($current_date < $event_from_date) {
                $status = 'Upcoming';
            } elseif ($current_date <= $event_to_date) {
                $status = 'Ongoing';
            }
        
            // Process file uploads with error handling
            $pics = [];
            for ($i = 1; $i <= 3; $i++) {
                $fileKey = 'pic' . $i;
                if (isset($_FILES[$fileKey]) && $_FILES[$fileKey]['error'] == UPLOAD_ERR_OK) {
                    $pics[$i] = file_get_contents($_FILES[$fileKey]['tmp_name']);
                } else {
                    $pics[$i] = null; // No file uploaded or error occurred
                }
            }
        
            // Insert event into database
            $stmt = $conn->prepare("INSERT INTO events (event_name, description, event_from_date, event_to_date, branch, status, pic1, pic2, pic3, winners) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssssss", $event_name, $description, $event_from_date, $event_to_date, $branch, $status, $pics[1], $pics[2], $pics[3], $winners);
            
            if ($stmt->execute()) {
                echo "Event added successfully!";
            } else {
                echo "Error: " . $stmt->error; // Output the error message for debugging
            }
            $stmt->close();
        
            // Redirect to dashboard to prevent resubmission on refresh
            header("Location: admin_dashboard.php?success=event_added");
            exit();
        } elseif (isset($_POST['modify_event'])) {
            $eventId = $_POST['event_id'] ?? null;
            $eventName = $_POST['event_name'] ?? '';
            $eventDescription = $_POST['event_description'] ?? '';
            $eventStartDate = $_POST['event_start_date'] ?? null;
            $eventEndDate = $_POST['event_end_date'] ?? null;
            $eventWinner = $_POST['event_winner'] ?? null;
        
            // Initialize variables for pictures
            $pic1 = null;
            $pic2 = null;
            $pic3 = null;
        
            // Retrieve the current pictures from the database
            $currentPicsQuery = $conn->prepare("SELECT pic1, pic2, pic3 FROM events WHERE event_id = ?");
            $currentPicsQuery->bind_param("i", $eventId);
            $currentPicsQuery->execute();
            $currentPicsResult = $currentPicsQuery->get_result();
            $currentPics = $currentPicsResult->fetch_assoc();
        
            // Handle file uploads, but keep current pictures if new ones are not uploaded
            if (isset($_FILES['event_pic1']) && $_FILES['event_pic1']['error'] == 0) {
                $pic1 = $_FILES['event_pic1']['name'];
                move_uploaded_file($_FILES['event_pic1']['tmp_name'], 'path/to/upload/' . $pic1);
            } else {
                $pic1 = $currentPics['pic1'];
            }
        
            if (isset($_FILES['event_pic2']) && $_FILES['event_pic2']['error'] == 0) {
                $pic2 = $_FILES['event_pic2']['name'];
                move_uploaded_file($_FILES['event_pic2']['tmp_name'], 'path/to/upload/' . $pic2);
            } else {
                $pic2 = $currentPics['pic2'];
            }
        
            if (isset($_FILES['event_pic3']) && $_FILES['event_pic3']['error'] == 0) {
                $pic3 = $_FILES['event_pic3']['name'];
                move_uploaded_file($_FILES['event_pic3']['tmp_name'], 'path/to/upload/' . $pic3);
            } else {
                $pic3 = $currentPics['pic3'];
            }
        
            // SQL Update Statement
            $sql = "UPDATE events SET event_name = ?, description = ?, event_from_date = ?, event_to_date = ?, pic1 = ?, pic2 = ?, pic3 = ?, winners = ? WHERE event_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssissi", $eventName, $eventDescription, $eventStartDate, $eventEndDate, $pic1, $pic2, $pic3, $eventWinner, $eventId);
$stmt->execute();
            if ($stmt->error) {
                echo "Error updating event: " . $stmt->error;
            } else {
                echo "Event updated successfully!";
                header('Location: admin_dashboard.php?success=event_modified');
                exit();
            }
        }
        
        
        
    }



    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    

        <style>
            body {
                background-color: #f8f9fa;
            }
            .header {
        background-color: #0056b3; /* A slightly darker blue for better contrast */
        color: #ffffff; /* crisp white text */
        padding: 10px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        text-shadow: 1px 1px 2px #000; /* Adding a subtle shadow to text for better legibility */
    }

    .header h2 {
        margin: 0;
    }

    .admin-info {
        font-size: 16px;
        font-weight: bold;
    }
            .sidebar {
                height: 100%;
                width: 250px;
                position: fixed;
                z-index: 1;
                top: 0;
                left: 0;
                background-color: #343a40;
                padding-top: 20px;
            }
            .sidebar a {
                padding: 10px 15px;
                text-decoration: none;
                font-size: 18px;
                color: white;
                display: block;
            }
            .sidebar a:hover {
                background-color: #495057;
            }
            .sidebar .sub-menu {
                display: none;
                padding-left: 20px;
            }
            .main {
                margin-left: 260px;
                padding: 20px;
            }
        
            .form-section {
                display: none;
            }
            .event-card {
                border: 1px solid #ccc;
                border-radius: 5px;
                padding: 15px;
                margin-bottom: 10px;
            }
        

button {
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    background-color: #007bff;
    color: white;
}

button:hover {
    background-color: #0056b3;
}

button:focus {
    outline: none;
}

            .table {
    width: 100%;
    border-collapse: collapse;
}
.table th, .table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}
.sub-menu {
    display: none;
}
.hidden {
    display: none !important; /* override any inline styles */
}

/* Chat Popup Container */
.chat-popup {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 400px;
    max-width: 100%;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    z-index: 1000;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    animation: fadeIn 0.3s ease-in-out;
}

/* Animation for popup visibility */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Chat Header Styling */
.chat-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background-color: #007bff;
    color: #fff;
    border-bottom: 1px solid #ddd;
    position: relative; /* To position buttons absolutely */
}

/* Close and Minimize Button */
.close-button, .minimize-button {
    background: none;
    border: none;
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    position: absolute; /* Positioning them on top right */
    right: 10px; /* Space from the right */
}

.minimize-button {
    right: 40px; /* Positioning the minimize button slightly to the left of the close button */
}


.chat-header h1 {
    font-size: 18px;
    margin: 0;
}


.close-button:hover, .minimize-button:hover {
    color: #ccc;
}

/* Messages Container */
.messages {
    padding: 10px;
    height: 300px;
    overflow-y: auto;
    flex-grow: 1;
    background-color: #f9f9f9;
    border-bottom: 1px solid #ddd;
}

/* Chat Input Field */
.chat-input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    margin: 10px;
    box-sizing: border-box;
}

/* Send Button */
#sendButton {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px;
    margin: 10px;
    border-radius: 5px;
    cursor: pointer;
}

#sendButton:hover {
    background-color: #0056b3;
}

/* Responsive Layout */
@media (max-width: 500px) {
    .chat-popup {
        width: 90%;
    }
}






        </style>
        
    </head>
<body>
    <div class="sidebar">
        <h2 class="text-white text-center">Admin Panel</h2>
        <a href="javascript:void(0);" onclick="toggleSubMenu('students-menu')">Manage Students</a>
        <div id="students-menu" class="sub-menu">
            <a href="javascript:void(0);" onclick="showForm('add-student-form')">Add Student
            </a>
            <a href="javascript:void(0);" onclick="showForm('modify-student-form')">Modify / Remove Student</a>
        </div>

        <a href="javascript:void(0);" onclick="toggleSubMenu('events-menu')">Manage Events</a>
        <div id="events-menu" class="sub-menu">
            <a href="javascript:void(0);" onclick="showForm('add-event-form')">Add Event</a>
            <a href="javascript:void(0);" onclick="showForm('modify-event-form')">Modify / Cancel Events </a>
            <a href="javascript:void(0);" onclick="showForm('remove-event-form')">Cancelled Events</a>
        </div>

        <a href="javascript:void(0);" onclick="toggleSubMenu('approvals-menu')">Approvals</a>
        <div id="approvals-menu" class="sub-menu">
            <a href="javascript:void(0);" onclick="showForm('pending-students')">Pending Students</a>
            <a href="javascript:void(0);" onclick="showForm('approved-students')">Approved Students</a>
            <a href="javascript:void(0);" onclick="showForm('rejected-students')">Rejected Students</a>
        </div>
        <a href="javascript:void(0);" onclick="toggleSubMenu('chat-menu')">Chat</a>
<div id="chat-menu" class="sub-menu">
    <a href="javascript:void(0);" onclick="showChat()">View Conversations</a>
</div>
        

        <a href="logout.php" class="text-danger">Logout</a>
    </div>

    <div class="main">
    <div class="header">
    <h2>Admin Dashboard</h2>
    <button class="btn" style="background: linear-gradient(90deg, #ff6a00, #ee0979); color: white; border-radius: 25px; padding: 10px 20px; border: none; margin-left: 10px; transition: background 0.3s, transform 0.3s;" onclick="openAdminGroupChatPopup()">
    Chat with Admins
</button>


<button class="btn" 
        style="background: linear-gradient(90deg, #ff6a00, #ee0979); color: white; border-radius: 25px; padding: 10px 20px; border: none; margin-left: 10px;"
        onclick="openBranchChatPopup('<?php echo $_SESSION['admin_branch']; ?>')">
    Chat with <?php echo $_SESSION['admin_branch']; ?> Group
</button>









    <div class="admin-info">
        <span>Branch: <?php echo $branch; ?></span> |
        <span>Admin: <?php echo $adminName; ?></span>
    </div>
</div>




        <div id="pending-students" class="form-section">
            <h3>Pending Students</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Roll Number</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($student = $pending_approvals_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $student['name']; ?></td>
                            <td><?php echo $student['roll_number']; ?></td>
                            <td>
                                <button class="btn btn-success" onclick="approveStudent(<?php echo $student['student_id']; ?>)">Approve</button>
                                <button class="btn btn-danger" onclick="rejectStudent(<?php echo $student['student_id']; ?>)">Reject</button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div id="approved-students" class="form-section">
            <h3>Approved Students</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Roll Number</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($student = $approved_students_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $student['name']; ?></td>
                            <td><?php echo $student['roll_number']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div id="rejected-students" class="form-section">
            <h3>Rejected Students</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Roll Number</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($student = $rejected_students_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $student['name']; ?></td>
                            <td><?php echo $student['roll_number']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div id="add-student-form" class="form-section" style="display: block; padding: 15px; background-color: white; border-radius: 10px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); margin: 20px auto; width: 50%; max-width: 600px;" >
    <div style="padding: 20px;">
        <h3 style="text-align: center; margin-bottom: 15px;">Add Student</h3>
        <form method="POST">
            <div style="margin-bottom: 15px;">
                <label for="student_name" style="font-weight: bold;">Name</label>
                <input type="text" class="form-control" name="student_name" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
            </div>
            <div style="margin-bottom: 15px;">
                <label for="student_age" style="font-weight: bold;">Age</label>
                <input type="number" class="form-control" name="student_age" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
            </div>
            <div style="margin-bottom: 15px;">
                <label for="student_roll_number" style="font-weight: bold;">Roll Number</label>
                <input type="text" class="form-control" name="student_roll_number" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
            </div>
            <div style="margin-bottom: 15px;">
                <label for="student_dob" style="font-weight: bold;">Date of Birth</label>
                <input type="date" class="form-control" name="student_dob" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
            </div>
            <div style="margin-bottom: 15px;">
                <label for="student_mobile_number" style="font-weight: bold;">Mobile Number</label>
                <input type="text" class="form-control" name="student_mobile_number" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
            </div>
            <div style="margin-bottom: 15px;">
                <label for="student_password" style="font-weight: bold;">Password</label>
                <input type="password" class="form-control" name="student_password" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
            </div>
            <div style="margin-bottom: 15px;">
                <label for="approval_status" style="font-weight: bold;">Approval Status</label>
                <select name="approval_status" class="form-control" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
                    <option value="Pending">Pending</option>
                    <option value="Approved">Approved</option>
                    <option value="Rejected">Rejected</option>
                </select>
            </div>
            <button type="submit" name="add_student" class="btn btn-primary" style="background-color: #0056b3; border: none; color: white; padding: 10px 20px; text-align: center; text-decoration: none; display: inline-block; font-size: 16px; margin: 4px 2px; cursor: pointer; width: 100%;">Add Student</button>
        </form>
    </div>
</div>

<div id="modify-student-form" class="form-section">
    <h3>Modify / Remove Student</h3>
    <table class="table table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Age</th>
                <th>Date of Birth</th>
                <th>Mobile Number</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($student = $students_result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $student['student_id']; ?></td>
                    <td><?php echo $student['name']; ?></td>
                    <td><?php echo $student['age']; ?></td>
                    <td><?php echo $student['dob']; ?></td>
                    <td><?php echo $student['mobile_number']; ?></td>
                    <td>
    <button class="btn btn-primary" onclick='loadForm(`<?php echo htmlspecialchars(json_encode($student)); ?>`)'>Edit</button>
    <button class="btn btn-danger" onclick="confirmDelete('<?php echo $student['name']; ?>', <?php echo $student['student_id']; ?>)">Delete</button>
</td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<!-- Update the "Edit Student Form" Design -->
<div id="edit-student-form" class="card mx-auto mt-5 shadow-lg" style="width: 80%; display:none;">
    <div class="card-body">
        <h5 class="card-title">Edit Student</h5>
        <form method="POST">
            <input type="hidden" name="student_id" id="edit-student-id">
            <div class="form-group">
                <label for="edit-student-name">Name</label>
                <input type="text" class="form-control" name="student_name" id="edit-student-name" required>
            </div>
            <div class="form-group">
                <label for="edit-student-age">Age</label>
                <input type="number" class="form-control" name="student_age" id="edit-student-age" required>
            </div>
            <div class="form-group">
                <label for="edit-student-roll-number">Roll Number</label>
                <input type="text" class="form-control" name="student_roll_number" id="edit-student-roll-number" required>
            </div>
            <div class="form-group">
                <label for="edit-student-dob">Date of Birth</label>
                <input type="date" class="form-control" name="student_dob" id="edit-student-dob" required>
            </div>
            <div class="form-group">
                <label for="edit-student-mobile">Mobile Number</label>
                <input type="text" class="form-control" name="student_mobile_number" id="edit-student-mobile" required>
            </div>
            <button type="submit" name="modify_student" class="btn btn-success">Save Changes</button>
        </form>
    </div>
</div>

<div id="add-event-form" class="form-section" style="max-width: 600px; margin: 40px auto; padding: 20px; background-color: #f9f9f9; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
    <h3 style="text-align: center; color: #333;">Add Event</h3>
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group" style="margin-bottom: 20px;">
            <label for="event_name" style="display: block; margin-bottom: 5px;">Event Name:</label>
            <input type="text" class="form-control" name="event_name" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        </div>
        <div class="form-group" style="margin-bottom: 20px;">
            <label for="description" style="display: block; margin-bottom: 5px;">Description:</label>
            <textarea class="form-control" name="description" required style="width: 100%; padding: 8px; height: 120px; border: 1px solid #ccc; border-radius: 4px;"></textarea>
        </div>
        <div class="form-group" style="margin-bottom: 20px;">
            <label for="event_from_date" style="display: block; margin-bottom: 5px;">Event Start Date:</label>
            <input type="date" class="form-control" name="event_from_date" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        </div>
        <div class="form-group" style="margin-bottom: 20px;">
            <label for="event_to_date" style="display: block; margin-bottom: 5px;">Event End Date:</label>
            <input type="date" class="form-control" name="event_to_date" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        </div>
        <div class="form-group" style="margin-bottom: 20px;">
            <label for="winners" style="display: block; margin-bottom: 5px;">Winners:</label>
            <input type="text" class="form-control" name="winners" placeholder="Enter winners" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;">
        </div>
        <div class="form-group" style="margin-bottom: 20px;">
            <label for="pic1" style="display: block; margin-bottom: 5px;">Main Event Picture:</label>
            <input type="file" class="form-control-file" name="pic1" required style="display: block; width: 100%;">
        </div>
        <div class="form-group" style="margin-bottom: 20px;">
            <label for="pic2" style="display: block; margin-bottom: 5px;">Additional Event Picture (optional):</label>
            <input type="file" class="form-control-file" name="pic2" style="display: block; width: 100%;">
        </div>
        <div class="form-group" style="margin-bottom: 20px;">
            <label for="pic3" style="display: block; margin-bottom: 5px;">Additional Event Picture (optional):</label>
            <input type="file" class="form-control-file" name="pic3" style="display: block; width: 100%;">
        </div>
        <div style="text-align: center;">
            <button type="submit" name="add_event" class="btn btn-primary" style="padding: 10px 20px; font-size: 16px;">Add Event</button>
        </div>
    </form>
</div>
<div id="modify-event-form" class="form-section">
    <h3>Modify / Remove Event</h3>
    <table class="table table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Event Name</th>
                <th>Description</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($event = $events_result->fetch_assoc()) {
                // Base64 encode image data to ensure it doesn't break JSON encoding
                $event['pic1'] = ($event['pic1'] !== null) ? base64_encode($event['pic1']) : null;
                $event['pic2'] = ($event['pic2'] !== null) ? base64_encode($event['pic2']) : null;
                $event['pic3'] = ($event['pic3'] !== null) ? base64_encode($event['pic3']) : null;

                // JSON Encode the entire event data
                $jsonEvent = htmlspecialchars(json_encode($event), ENT_QUOTES, 'UTF-8');
            ?>
                <tr id="event-row-<?= $event['event_id']; ?>">
                    <td><?= htmlspecialchars($event['event_id']); ?></td>
                    <td><?= htmlspecialchars($event['event_name']); ?></td>
                    <td><?= htmlspecialchars($event['description']); ?></td>
                    <td><?= htmlspecialchars($event['event_from_date']); ?></td>
                    <td><?= htmlspecialchars($event['event_to_date']); ?></td>
                    <td>
                        <button class="btn btn-primary" onclick='loadEventForm(`<?= $jsonEvent; ?>`)'>Edit</button>
                        <button class="btn btn-danger" onclick="confirmEventDelete('<?= htmlspecialchars($event['event_name']); ?>', <?= $event['event_id']; ?>)">Cancel</button>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
   <div id="modify-cancel-events" class="tab-content">
    <div id="edit-event-form" class="card mx-auto mt-5 shadow-lg" style="width: 80%; display:none;">
        <div class="card-body">
            <h5 class="card-title">Edit Event</h5>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="event_id" id="edit-event-id">
                <div class="form-group">
                    <label for="edit-event-name">Event Name</label>
                    <input type="text" class="form-control" name="event_name" id="edit-event-name" required>
                </div>
                <div class="form-group">
                    <label for="edit-event-description">Description</label>
                    <textarea class="form-control" name="event_description" id="edit-event-description" required></textarea>
                </div>
                <div class="form-group">
                    <label for="edit-event-start-date">Start Date</label>
                    <input type="date" class="form-control" name="event_start_date" id="edit-event-start-date" required>
                </div>
                <div class="form-group">
                    <label for="edit-event-end-date">End Date</label>
                    <input type="date" class="form-control" name="event_end_date" id="edit-event-end-date" required>
                </div>
                <div class="form-group">
    <label for="edit-event-winner">Event Winner (optional)</label>
    <input type="text" class="form-control" name="event_winner" id="edit-event-winner">
</div>
                <div class="form-group">
                    <label for="edit-event-pic1">Image 1 (optional)</label>
                    <input type="file" class="form-control" name="event_pic1" id="edit-event-pic1" accept="image/*">
                    <div id="existing-image-1"></div> <!-- Container for existing image 1 -->
                </div>
                <div class="form-group">
                    <label for="edit-event-pic2">Image 2 (optional)</label>
                    <input type="file" class="form-control" name="event_pic2" id="edit-event-pic2" accept="image/*">
                    <div id="existing-image-2"></div> <!-- Container for existing image 2 -->
                </div>
                <div class="form-group">
                    <label for="edit-event-pic3">Image 3 (optional)</label>
                    <input type="file" class="form-control" name="event_pic3" id="edit-event-pic3" accept="image/*">
                    <div id="existing-image-3"></div> <!-- Container for existing image 3 -->
                </div>
                <button type="submit" name="modify_event" class="btn btn-success">Save Changes</button>
            </form>
        </div>
    </div>
</div>



<div id="remove-event-form" class="form-section" style="display: none;">
    <h3>Cancelled Events</h3>
    <table class="table table-hover" style="width: 100%; border-collapse: collapse; margin: 25px 0; font-size: 0.9em; min-width: 400px; box-shadow: 0 0 20px rgba(0,0,0,0.15);">
        < <thead>
        <tr style="background-color: #009879; color: #ffffff; text-align: left; font-weight: bold;">
            <th style="padding: 12px 15px;">ID</th>
            <th style="padding: 12px 15px;">Event Name</th>
            <th style="padding: 12px 15px;">Description</th>
            <th style="padding: 12px 15px;">Start Date</th>
            <th style="padding: 12px 15px;">End Date</th>
        </tr>
    </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM events WHERE status = 'Cancelled'";
            $result = $conn->query($sql);
            while ($event = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= htmlspecialchars($event['event_id']); ?></td>
                    <td><?= htmlspecialchars($event['event_name']); ?></td>
                    <td><?= htmlspecialchars($event['description']); ?></td>
                    <td><?= htmlspecialchars($event['event_from_date']); ?></td>
                    <td><?= htmlspecialchars($event['event_to_date']); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<div id="chatPopup" class="chat-popup" style="display: none;">
    <div class="chat-header">
        <h1 id="studentName">Chat with Student</h1> <!-- Placeholder for student name -->
        <button class="close-button" onclick="closeChatPopup()">×</button>
        <button class="minimize-button" onclick="toggleChatPopup()">-</button>
    </div>
    <div id="messages" class="messages"></div>
    <form id="chatForm" action="javascript:void(0);" method="POST" onsubmit="return sendMessage();">
        <input type="text" id="chatMessage" name="message" placeholder="Type message..." class="chat-input" required>
        <input type="hidden" name="studentId" id="receiverId">
        <button type="button" id="sendButton">Send</button>
    </form>
</div>


<div id="adminGroupChatPopup" class="chat-popup" style="display:none;">
    <div class="chat-header">
        <h1>Admin Group Chat</h1>
        <button class="minimize-button" onclick="toggleChatPopup()">-</button>
        <button class="close-button" onclick="closeAdminGroupChatPopup()">x</button>
    </div>

    <div id="groupMessages" class="messages">
        <!-- Admin group messages will be loaded here -->
    </div>

    <textarea id="groupChatMessage" class="chat-input" placeholder="Type your message..."></textarea>
    <button id="sendButton" onclick="sendGroupMessage()">Send</button>
</div>



<div id="groupChatPopup" class="chat-popup" style="display: none;">
    <div class="chat-header">
        <h1 id="groupChatTitle">Group Chat</h1>
        <button class="close-button" onclick="closeUniqueAdminGroupChatPopup()">×</button>
        <button class="minimize-button" onclick="toggleGroupChatPopup()">-</button>
    </div>
    <div id="groupChatMessagesContainer" class="messages"></div>
    <form id="groupChatForm" action="javascript:void(0);" method="POST">
        <input type="text" id="adminGroupChatMessage" name="message" placeholder="Type message..." class="chat-input" required>
        <input type="hidden" name="branch" id="branchName">
        <input type="hidden" name="studentId" id="studentId">
        <input type="hidden" name="group_id" id="groupId">
        <button type="button" id="groupSendButton">Send</button>
    </form>
</div>




<!-- Section where the student list will load -->
<section id="content-area"></section>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js" defer></script>

    <!-- Popper.js for Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" defer></script>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" defer></script>

    <!-- jQuery UI CSS and JS for draggable chat popup -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="//code.jquery.com/ui/1.12.1/jquery-ui.js" defer></script>



<script>





function openBranchChatPopup(branch) {
    // Fetch group ID for the admin's branch
    $.ajax({
        url: 'get_group_id.php',
        type: 'POST',
        data: { branch: branch },
        success: function(data) {
            var response = JSON.parse(data);
            if (response.group_id) {
                $('#groupChatTitle').text('Group Chat for ' + branch);
                $('#groupId').val(response.group_id); // Set group ID in the hidden input
                loadGroupMessages(response.group_id); // Load messages for the branch group
                $('#groupChatPopup').fadeIn(); // Show the chat popup
            } else {
                alert("Error fetching group ID: " + response.error);
            }
        },
        error: function(xhr, status, error) {
            console.error("Error fetching group ID:", error);
        }
    });
}

function loadGroupMessages(groupId) {
    console.log("Loading messages for group ID:", groupId); // Log the group ID
    $.ajax({
        url: 'get_group_chat_messages.php',
        type: 'POST',
        data: { group_id: groupId },
        success: function(data) {
            console.log("Response Data:", data); // Check the response data
            var messages = JSON.parse(data);
            if (Array.isArray(messages) && messages.length > 0) {
                $('#groupChatMessagesContainer').empty(); // Clear existing messages
                messages.forEach(function(message) {
                    $('#groupChatMessagesContainer').append(`<div class="message"><strong>${message.sender}:</strong> ${message.message} <span class="timestamp">${message.timestamp}</span></div>`);
                });
                scrollToBottomGroup(); // Scroll to the latest message
            } else {
                $('#groupChatMessagesContainer').html('<div>No messages yet for this group.</div>'); // Show no messages message
            }
        },
        error: function(xhr, status, error) {
            console.error("Failed to load messages: " + status + ", " + error);
        }
    });
}

function sendUniqueAdminGroupMessage() {
    var message = $('#adminGroupChatMessage').val().trim(); // Use new ID here
    var adminId = '<?php echo $_SESSION['admin_id']; ?>'; // Ensure this ID is set correctly in your context
    var groupId = $('#groupId').val(); // Get group ID from hidden input

    if (!message) {
        alert("Please type a message.");
        return;
    }

    $.ajax({
        type: "POST",
        url: "send_group_chat_message.php",
        data: {
            message: message,
            group_id: groupId, // Send group ID
            senderId: adminId,
            userType: 'admin', // Specify sender type
            branch: '<?php echo $_SESSION['admin_branch']; ?>' // Send admin branch
        },
        success: function(response) {
            $('#adminGroupChatMessage').val(''); // Clear message input
            loadGroupMessages(groupId); // Refresh messages
        },
        error: function(xhr, status, error) {
            console.error("Error sending message:", error);
            alert("An error occurred while sending the message.");
        }
    });
}

// Event listeners for sending messages
$(document).ready(function() {
    $('#groupSendButton').on('click', function() {
        sendUniqueAdminGroupMessage();
    });

    $('#adminGroupChatMessage').on('keypress', function(event) { // Use new ID here
        if (event.key === 'Enter') {
            event.preventDefault(); // Prevent default form submission
            sendUniqueAdminGroupMessage();
        }
    });

    // Make the chat popup draggable
    $('#groupChatPopup').draggable({
        handle: '.chat-header' // Allow dragging only from the header
    });
});

function closeUniqueAdminGroupChatPopup() {
    $('#groupChatPopup').fadeOut();
}

// Scroll to the bottom of the messages container
function scrollToBottomGroup() {
    var messagesContainer = $('#groupChatMessagesContainer');
    messagesContainer.scrollTop(messagesContainer[0].scrollHeight);
}







            function approveStudent(studentId) {
                const xhr = new XMLHttpRequest();
                xhr.open("POST", "admin_dashboard.php", true);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhr.onload = function() {
                    if (this.status == 200) {
                        alert('Student approved successfully');
                        location.reload();
                    }
                };
                xhr.send("approve_student=1&student_id=" + studentId);
            }

            function rejectStudent(studentId) {
                const xhr = new XMLHttpRequest();
                xhr.open("POST", "admin_dashboard.php", true);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhr.onload = function() {
                    if (this.status == 200) {
                        alert('Student rejected successfully');
                        location.reload();
                    }
                };
                xhr.send("reject_student=1&student_id=" + studentId);
            }

            function toggleSubMenu(id) {
        const subMenu = document.getElementById(id);
        const editStudentForm = document.getElementById('edit-student-form');
        
        // Hide all sub-menus
        document.querySelectorAll('.sub-menu').forEach(menu => {
            if (menu.id !== id) {
                menu.style.display = 'none';
            }
        });

        // Toggle the clicked sub-menu
        subMenu.style.display = subMenu.style.display === 'block' ? 'none' : 'block';

        // Hide the edit student form if not in 'Modify Student' menu
        if (id !== 'students-menu') {
            if(editStudentForm) {
                editStudentForm.style.display = 'none';
            }
        }

    }

    function showForm(formId) {
        const forms = document.querySelectorAll('.form-section');
        forms.forEach(form => form.style.display = 'none'); // Hide all forms
        
        // Show the selected form
        const selectedForm = document.getElementById(formId);
        if (selectedForm) {
            selectedForm.style.display = 'block';
            
            // Hide the edit form when showing other forms (except modify-student-form)
            if (formId !== 'modify-student-form' && document.getElementById('edit-student-form')) {
                document.getElementById('edit-student-form').style.display = 'none';
            }
        }
    }
            window.onload = function() {
        const urlParams = new URLSearchParams(window.location.search);
        const success = urlParams.get('success');
        const name = urlParams.get('name');

        if (success === 'add_student') {
            alert(`The student ${name} has been successfully added.`);
            clearUrlParams();
        } else if (success === 'student_modified') {
            alert('Student details have been updated successfully.');
            clearUrlParams();
        }
        else if (success === 'event_added') {
            alert('Event has been successfully added.');
            window.history.replaceState({}, document.title, "/admin_dashboard.php"); // Remove parameters
        }
        
    };

    function clearUrlParams() {
        history.pushState({}, document.title, window.location.pathname);
    }
    function loadForm(student) {
        var studentData = JSON.parse(student);
        // Set form values
        document.getElementById('edit-student-id').value = studentData.student_id;
        document.getElementById('edit-student-name').value = studentData.name;
        document.getElementById('edit-student-age').value = studentData.age;
        document.getElementById('edit-student-roll-number').value = studentData.roll_number;
        document.getElementById('edit-student-dob').value = studentData.dob;
        document.getElementById('edit-student-mobile').value = studentData.mobile_number;
        
        // Show the form only in 'Modify Student' tab
        document.querySelectorAll('.form-section').forEach(form => form.style.display = 'none');
        document.getElementById('modify-student-form').style.display = 'block';
        document.getElementById('edit-student-form').style.display = 'block';
    }
    function loadEventForm(eventData) {
    // Hide all other form sections first
    const forms = document.querySelectorAll('.form-section');
    forms.forEach(form => form.style.display = 'none'); // Hide all forms

    // Parse the event data
    const event = JSON.parse(eventData);

    // Populate the form fields
    document.getElementById('edit-event-id').value = event.event_id;
    document.getElementById('edit-event-name').value = event.event_name;
    document.getElementById('edit-event-description').value = event.description;
    document.getElementById('edit-event-start-date').value = event.event_from_date;
    document.getElementById('edit-event-end-date').value = event.event_to_date;

    if (event.winner) {
        document.getElementById('edit-event-winner').value = event.winner;
    }


    // Display existing images
    const image1Container = document.getElementById('existing-image-1');
    const image2Container = document.getElementById('existing-image-2');
    const image3Container = document.getElementById('existing-image-3');

    // Clear previous images
    image1Container.innerHTML = '';
    image2Container.innerHTML = '';
    image3Container.innerHTML = '';

    // Check and display existing images
    if (event.pic1) {
        image1Container.innerHTML = `<img src="path/to/upload/${event.pic1}" alt="Image 1" style="max-width: 100px; max-height: 100px;"/>`;
    }
    if (event.pic2) {
        image2Container.innerHTML = `<img src="path/to/upload/${event.pic2}" alt="Image 2" style="max-width: 100px; max-height: 100px;"/>`;
    }
    if (event.pic3) {
        image3Container.innerHTML = `<img src="path/to/upload/${event.pic3}" alt="Image 3" style="max-width: 100px; max-height: 100px;"/>`;
    }

    // Show the edit form
    document.getElementById('edit-event-form').style.display = 'block';
}



    function confirmDelete(studentName, studentId) {
        if (confirm(`Are you sure you want to delete ${studentName}?`)) {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "admin_dashboard.php", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.onload = function() {
                if (this.status == 200) {
                    alert('Student deleted successfully');
                    location.reload();
                }
            };
            xhr.send("remove_student=1&student_id=" + studentId);
        }
    }
    function checkAndRemoveStudent() {
        var rollNumber = document.getElementById('student_roll_number').value;
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "admin_dashboard_check_student.php", true); // This page should check if student exists in database
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onload = function () {
            if (this.status == 200 && this.responseText !== '') {
                var response = JSON.parse(this.responseText);
                if (confirm(`Are you sure you want to delete ${response.name} with Roll Number: ${rollNumber}?`)) {
                    deleteStudent(rollNumber);
                }
            } else {
                alert('No student found with the provided Roll Number.');
            }
        };
        xhr.send("roll_number=" + rollNumber);
        return false; // To prevent form from submitting traditionally
    }

    function deleteStudent(rollNumber) {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "admin_dashboard_delete_student.php", true); // This handles the actual deletion
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onload = function () {
            if (this.status == 200) {
                alert('Student successfully deleted');
                document.getElementById('student_roll_number').value = ""; // Reset input
            }
        };
        xhr.send("roll_number=" + rollNumber);
    }
    function editEvent(eventId, eventName, description, eventFromDate, eventToDate) {
        document.querySelector('input[name="event_id"]').value = eventId;
        document.querySelector('input[name="event_name"]').value = eventName;
        document.querySelector('textarea[name="description"]').value = description;
        document.querySelector('input[name="event_from_date"]').value = eventFromDate;
        document.querySelector('input[name="event_to_date"]').value = eventToDate;

        window.location.href = '#modify-event-form'; // Scrolls to the form
    }


    document.getElementById('edit-student-roll-number').value = studentData.roll_number;

    function confirmEventDelete(eventName, eventId) {
        if (confirm(`Are you sure you want to cancel the event: ${eventName}?`)) {
            $.ajax({
                type: 'POST',
                url: 'cancel_event.php',  // Ensure this URL correctly points to your PHP backend script responsible for cancellation
                data: { 'event_id': eventId, 'cancel_event': true }, // You need to send `cancel_event`
                success: function(response) {
                    if (response.trim() === 'success') {
                        alert(`Event '${eventName}' has been successfully cancelled.`);
                        $('#event-row-' + eventId).fadeOut('slow');  // Optionally hiding the row if needed
                    } else {
                        alert('Error cancelling event. ' + response);
                    }
                },
                error: function() {
                    alert('Request failed. Please try again later.'); 
                }
            });
        }
    }
    function showCancelledEvents() {
        var x = document.getElementById('remove-event-form');
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }
    function refreshCancelledEvents() {
        $('#remove-event-form').load(document.URL +  ' #remove-event-form');
    }
    
    const adminId = <?php echo json_encode($_SESSION['admin_id']); ?>;


function showChat() {
    $('.form-section').hide();

    $('#registered-students').show();
    fetch('getConversations.php')
    .then(response => response.text())
    .then(html => {
        document.getElementById('content-area').innerHTML = html;
    })
    .catch(err => console.error('Failed to load content: ', err));
}
var messagePollingInterval;

// Function to make the chat popup draggable
function makePopupDraggable(popup) {
    var posX = 0, posY = 0, mouseX = 0, mouseY = 0;
    var header = popup.querySelector('.chat-header');

    header.onmousedown = function(e) {
        e.preventDefault();
        // Get the current mouse cursor position
        mouseX = e.clientX;
        mouseY = e.clientY;

        // Call function when the mouse moves
        document.onmousemove = function(e) {
            e.preventDefault();

            // Calculate the new cursor position
            posX = mouseX - e.clientX;
            posY = mouseY - e.clientY;
            mouseX = e.clientX;
            mouseY = e.clientY;

            // Set the popup's new position
            popup.style.top = (popup.offsetTop - posY) + "px";
            popup.style.left = (popup.offsetLeft - posX) + "px";
        };

        // Stop moving the popup when mouse is released
        document.onmouseup = function() {
            document.onmousemove = null;
            document.onmouseup = null;
        };
    };
}

// Initialize the draggable functionality once the popup is opened
function openChatPopup(button) {
    var studentId = button.getAttribute('data-receiver-id');
    var studentName = button.getAttribute('data-student-name');

    clearInterval(messagePollingInterval);

    $.ajax({
        url: 'get_messages.php',
        type: 'POST',
        data: { student_id: studentId },
        success: function(data) {
            $('#messages').html(data);
            $('#chatPopup').fadeIn();
            $('#receiverId').val(studentId);
            $('#studentName').text('Chat with ' + studentName);
            scrollToBottom();

            // Start polling for new messages every 5 seconds
            messagePollingInterval = setInterval(function() {
                fetchMessages(studentId);
            }, 5000);

            // Make the chat popup draggable
            var popup = document.querySelector('.chat-popup');
            makePopupDraggable(popup);
        },
        error: function(xhr, status, error) {
            console.error("Failed to load messages: " + status + ", " + error);
        }
    });
}


function fetchMessages(studentId) {
    $.ajax({
        url: 'get_messages.php',
        type: 'POST',
        data: { student_id: studentId },
        success: function(data) {
            $('#messages').html(data);
            scrollToBottom(); // Scroll to the bottom to show the latest messages
        },
        error: function(xhr, status, error) {
            console.error("Failed to fetch messages: " + status + ", " + error);
        }
    });
}

// Add a function to close the chat popup
function closeChatPopup() {
    $('#chatPopup').fadeOut(); // Hide the popup
    clearInterval(messagePollingInterval); // Clear the polling interval when closing the popup
}


function sendMessage() {
    var chatMessage = $('#chatMessage').val();
    var studentId = $('#receiverId').val();

    if (!chatMessage.trim()) {
        alert("Please type a message.");
        return; // Stop function execution if no message
    }

    // AJAX request to sendMessages.php
    $.ajax({
        type: "POST",
        url: "sendMessages.php",
        data: {
            message: chatMessage,
            studentId: studentId
        },
        success: function(response) {
            var result = JSON.parse(response);
            if(result.status === 'success') {
                // Append message to chat window
                $('#messages').append('<div class="message sent">' + chatMessage + '</div>');
                $('#chatMessage').val(''); // Clear input field after sending
                scrollToBottom(); // Scroll to show new message
            } else {
                alert('Failed to send message. Please try again.');
            }
        },
        error: function() {
            alert('Error sending message. Please try again later.');
        }
    });
}

function scrollToBottom() {
    var messages = document.getElementById('messages');
    messages.scrollTop = messages.scrollHeight;
}

document.getElementById("chatMessage").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        event.preventDefault(); // Prevent new line
        sendMessage(); // Trigger the sendMessage function
    }
});

function toggleChatPopup() {
    var popup = document.getElementById('chatPopup');
    var messages = document.getElementById('messages');
    if (popup.style.height === "40px") {
        popup.style.height = "auto"; // Expand
        messages.style.display = "block"; // Show content
    } else {
        popup.style.height = "40px"; // Collapse to a smaller size
        messages.style.display = "none"; // Hide content
    }
}

function closeChatPopup() {
    $('#chatPopup').fadeOut(); // Smoothly hide the popup
    console.log("Chat popup closed");
}
 


var messagePollingInterval;

// When opening the popup, ensure it's draggable and starts polling
function openAdminGroupChatPopup() {
    clearInterval(messagePollingInterval); // Clear any previous intervals

    $.ajax({
        url: 'get_admin_messages.php',
        type: 'GET',
        success: function(data) {
            $('#groupMessages').html(data); // Load initial messages
            $('#adminGroupChatPopup').fadeIn();
            scrollToBottomGroup();

            // Start polling for new messages
            messagePollingInterval = setInterval(fetchGroupMessages, 5000);
            var popup = document.getElementById('adminGroupChatPopup');
            makePopupDraggable(popup); // Make popup draggable
        },
        error: function(xhr, status, error) {
            console.error("Failed to load admin group messages: " + status + ", " + error);
        }
    });
}

// Fetch new messages for the admin group chat
function fetchGroupMessages() {
    $.ajax({
        type: "GET",
        url: "get_admin_messages.php",
        success: function(response) {
            try {
                var messages = JSON.parse(response);
                $('#groupMessages').empty(); // Clear existing messages

                messages.forEach(function(message) {
                    $('#groupMessages').append('<div class="message"><strong>' + message.sender_name + ':</strong> ' + message.message_text + '</div>');
                });

                scrollToBottomGroup(); // Scroll to the bottom after updating messages
            } catch (e) {
                console.error("Invalid JSON response:", response);
            }
        },
        error: function() {
            alert('Error fetching messages. Please try again later.');
        }
    });
}


function sendGroupMessage() {
    var chatMessage = $('#groupChatMessage').val();

    if (!chatMessage.trim()) {
        alert("Please type a message.");
        return; // Stop function execution if no message
    }

    // AJAX request to send the message
    $.ajax({
        type: "POST",
        url: "send_admin_message.php",  // Server-side script for sending group messages
        data: { message: chatMessage }, // Only sending the message
        success: function(response) {
            try {
                var result = JSON.parse(response);
                if (result.status === 'success') {
                    $('#groupMessages').append('<div class="message sent">' + chatMessage + '</div>');
                    $('#groupChatMessage').val(''); // Clear input field after sending
                    scrollToBottomGroup(); // Scroll to show the new message
                } else {
                    alert('Failed to send message. Please try again.');
                }
            } catch (e) {
                console.error("Invalid JSON response:", response);
                alert('An error occurred. Please try again.');
            }
        },
        error: function() {
            alert('Error sending message. Please try again later.');
        }
    });
}


// Scroll to the bottom for admin group chat
function scrollToBottomGroup() {
    var messages = document.getElementById('groupMessages');
    messages.scrollTop = messages.scrollHeight;
}

// Close the admin group chat popup
function closeAdminGroupChatPopup() {
    $('#adminGroupChatPopup').fadeOut(); // Hide the popup
    clearInterval(messagePollingInterval); // Clear the polling interval when closing the popup
}

// Send the message when Enter is pressed
$(document).ready(function() {
    // Send the message when Enter is pressed
    $('#groupChatMessage').on('keypress', function(event) {
        if (event.key === "Enter") {
            event.preventDefault(); // Prevent new line
            sendGroupMessage(); // Trigger the sendMessage function
        }
    });
});





        </script>

    
</body>
</html>
