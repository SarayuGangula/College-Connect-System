<?php
session_start();
require 'db_connection.php'; // Make sure this is the correct path to your DB connection file

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(["status" => "error", "message" => "Admin not logged in"]);
    exit;
}

// Retrieve the message and student ID from POST request
$messageText = $_POST['message'] ?? '';
$studentId = $_POST['studentId'] ?? null; // Ensure this matches with your JavaScript
$adminId = $_SESSION['admin_id'];

// Validate input
if (!$messageText) {
    echo json_encode(["status" => "error", "message" => "Message text is empty"]);
    exit;
}

if (!$studentId) {
    echo json_encode(["status" => "error", "message" => "Student ID is missing"]);
    exit;
}

// Prepare the SQL query to insert the message
$query = "INSERT INTO messages (sender_id, receiver_id, message_text, timestamp) VALUES (?, ?, ?, NOW())";
$stmt = $conn->prepare($query);
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Failed to prepare statement"]);
    exit;
}

// Bind the parameters and execute the statement
$stmt->bind_param("iis", $adminId, $studentId, $messageText);
if (!$stmt->execute()) {
    echo json_encode(["status" => "error", "message" => $stmt->error]);
    exit;
}

// Return success response
echo json_encode(["status" => "success"]);

// Clean up
$stmt->close();
$conn->close();
?>
