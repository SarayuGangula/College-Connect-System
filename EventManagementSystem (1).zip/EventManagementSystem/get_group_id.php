<?php
session_start();
require 'db_connection.php';

if (!isset($_POST['branch'])) {
    echo json_encode(["error" => "No branch specified!"]);
    exit();
}

$branch_name = $_POST['branch'];

// Fetch group ID for the specified branch
$query = "SELECT group_id FROM groups WHERE branch_name = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $branch_name);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $group = $result->fetch_assoc();
    echo json_encode(["group_id" => $group['group_id']]);
} else {
    echo json_encode(["error" => "No group found for this branch!"]);
}
?>
