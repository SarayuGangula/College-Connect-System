<?php
session_start();
require 'db_connection.php';

if (isset($_POST['branch'])) {
    $branch = $_POST['branch'];
    $stmt = $conn->prepare("SELECT admin_id, username FROM admin WHERE branch = ?");
    $stmt->bind_param("s", $branch);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($admin = $result->fetch_assoc()) {
        echo json_encode($admin);
    } else {
        echo json_encode(null); // No admin found
    }
}
?>
