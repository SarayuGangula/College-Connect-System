<?php
session_start();
require 'db_connection.php';

$senderId = $_SESSION['admin_id']; // The ID of the admin sending the message
$messageText = $_POST['message'];

if (empty($messageText)) {
    echo json_encode(["status" => "error", "message" => "Message text is empty"]);
    exit;
}

// Since it's a group chat, we don't need a specific receiver_id
$query = "INSERT INTO messages (sender_id, message_text, user_type_sender, timestamp) VALUES (?, ?, 'admin', NOW())";
$stmt = $conn->prepare($query);
$stmt->bind_param("is", $senderId, $messageText);

if ($stmt->execute()) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
