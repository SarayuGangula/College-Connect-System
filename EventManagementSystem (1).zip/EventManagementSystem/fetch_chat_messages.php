<?php
session_start();
require 'db_connection.php'; // Database connection

// Fetch chat messages for the logged-in student
$student_id = $_SESSION['student_id'];
$stmt = $conn->prepare("SELECT m.message_text, m.message_date, 
    CASE 
        WHEN m.sender_type = 'admin' THEN (SELECT username FROM admin WHERE admin_id = m.sender_id) 
        ELSE (SELECT name FROM students WHERE student_id = m.sender_id) 
    END AS sender_name 
FROM messages m
WHERE (m.receiver_branch = (SELECT branch FROM students WHERE student_id = ?) AND m.receiver_id = ?)
OR (m.sender_id = ?)");
$stmt->bind_param("iii", $student_id, $student_id, $student_id);
$stmt->execute();
$messages = $stmt->get_result();

// Output messages as HTML
while ($message = $messages->fetch_assoc()) {
    echo '<div class="chat-message"><strong>' . htmlspecialchars($message['sender_name']) . ':</strong> <span>' . htmlspecialchars($message['message_text']) . '</span><small>' . $message['message_date'] . '</small></div>';
}
?>
