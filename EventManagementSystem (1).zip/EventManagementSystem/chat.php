<?php
session_start();
require 'db_connection.php'; // Ensure you have a valid database connection

// Verify user login status; redirect or notify if not logged in (implementation depends on your authentication logic)

if (!isset($_SESSION['user_id'])) {
    // Redirect to login page or show an error
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id']; // Assuming you store user ID in session
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Room</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div id="chat-box">
        <div class="chat-messages"></div>
        <input type="text" id="chat-message" placeholder="Type a message" autofocus>
        <button onclick="sendMessage()">Send</button>
    </div>

    <script>
        const userId = <?php echo json_encode($user_id); ?>;
        
        document.addEventListener('DOMContentLoaded', function() {
            const messageInput = document.querySelector('#chat-message');
            messageInput.addEventListener('keypress', function(e) {
                if (e.keyCode === 13) {  // Enter key pressed
                    e.preventDefault(); // Prevent form submission
                    sendMessage();
                }
            });

            openChat(); // Load chat messages on page load
        });

        function openChat() {
            fetch(`fetchMessages.php`)
            .then(response => response.json())
            .then(messages => {
                const messagesHTML = messages.map(msg =>
                    `<div><b>${msg.sender_name}:</b> ${msg.message_text}</div>`
                ).join('');
                document.querySelector('.chat-messages').innerHTML = messagesHTML;
                document.querySelector('.chat-messages').scrollTop = document.querySelector('.chat-messages').scrollHeight;
            })
            .catch(error => console.error('Error fetching messages:', error));
        }

        function sendMessage() {
            const message = document.querySelector('#chat-message').value;
            if (!message.trim()) return; // Prevent sending empty or all-space messages
            fetch('sendMessages.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `message=${encodeURIComponent(message)}&userId=${userId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === "success") {
                    openChat();  // Refresh chat messages after sending a message
                } else {
                    console.error('Failed to send message:', data.message);
                }
                document.querySelector('#chat-message').value = '';
            })
            .catch(error => console.error('Error sending message:', error));
        }
    </script>
</body>
</html>