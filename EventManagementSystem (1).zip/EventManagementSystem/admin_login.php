<?php
session_start();
require 'db_connection.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Debugging: Check what username and password are being sent
    echo "Attempting login with username: $username and password: $password<br>";

    // Query the database for admin
    $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ? AND password = ?");
    
    // Check if the statement was prepared successfully
    if (!$stmt) {
        die("SQL statement preparation failed: " . $conn->error);
    }

    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    // Debugging: Output number of rows returned
    echo "Number of rows returned: " . $result->num_rows . "<br>"; // Check how many rows were returned

    // Check if any rows are returned
    if ($result->num_rows > 0) {
        $admin_data = $result->fetch_assoc(); // Fetch the admin data
        $_SESSION['admin_id'] = $admin_data['admin_id']; // Store admin ID in session
        $_SESSION['admin_branch'] = $admin_data['branch']; // Store branch in session
        $_SESSION['admin_username'] = $admin_data['username']; // Store username in session
        header('Location: admin_dashboard.php'); // Redirect to admin dashboard
        exit();
    } else {
        echo "<div class='alert alert-danger'>Invalid login credentials!</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login Portal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: url('images/student_login_background.jpeg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 100%;
            max-width: 450px;
            background: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s;
        }

        .container:hover {
            transform: translateY(-5px);
        }

        .card-custom {
            border: none;
            margin: 0;
            padding: 0;
        }

        .card-header {
            background-color: #6c5ce7;
            color: white;
            padding: 15px;
            font-size: 24px;
            text-align: center;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .card-header:hover {
            background-color: #5a4cc1;
        }

        .form-group label {
            font-weight: 500;
            color: #333;
        }

        .btn-custom {
            background: linear-gradient(90deg, #6c5ce7, #a29bfe);
            border: none;
            color: white;
            padding: 12px;
            font-size: 18px;
            font-weight: bold;
            border-radius: 30px;
            transition: background 0.3s, box-shadow 0.3s;
        }

        .btn-custom:hover {
            box-shadow: 0 5px 15px rgba(163, 130, 255, 0.5);
        }

        .btn-secondary {
            background: transparent;
            border: 1px solid #6c5ce7;
            color: #6c5ce7;
            padding: 12px;
            font-size: 18px;
            font-weight: bold;
            border-radius: 30px;
            transition: background 0.3s, color 0.3s;
        }

        .btn-secondary:hover {
            background: #6c5ce7;
            color: white;
        }

        .form-control {
            border: 2px solid #ddd;
            transition: border-color 0.3s, box-shadow 0.3s;
            border-radius: 25px;
        }

        .form-control:focus {
            border-color: #6c5ce7;
            box-shadow: 0 0 5px rgba(108, 92, 231, 0.5);
        }

        .card-body {
            padding: 15px;
        }

        .text-center {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card card-custom">
            <div class="card-header">Admin Login Portal</div>
            <div class="card-body">
                <!-- Login Form -->
                <form method="POST" action="" id="login-form">
                    <input type="hidden" name="form_type" value="login">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" name="username" id="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" name="password" id="password" required>
                    </div>
                    <button type="submit" class="btn btn-custom btn-block">
                        <i class="fas fa-sign-in-alt"></i> Log In
                    </button>
                    <button type="button" class="btn btn-secondary btn-block" onclick="window.location.href='index.html';">Back</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</body>
</html>
