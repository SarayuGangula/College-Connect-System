<?php
session_start();
$adminBranch = $_SESSION['branch'] ?? '';

require 'db_connection.php'; // Your database connection code

$sql = "SELECT * FROM students WHERE branch = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $adminBranch);
$stmt->execute();
$result = $stmt->get_result();

echo '<table>';
echo '<tr><th>Name</th><th>Roll Number</th><th>Chat</th></tr>';
while ($row = $result->fetch_assoc()) {
    echo '<tr>';
    echo '<td>' . htmlspecialchars($row['name']) . '</td>';
    echo '<td>' . htmlspecialchars($row['roll_number']) . '</td>';
    echo '<td><button onclick="openChatPopup(this)" data-student-id="' . $row['student_id'] . '">Chat</button></td>';
    echo '</tr>';
}
echo '</table>';

$stmt->close();
$conn->close();
?>