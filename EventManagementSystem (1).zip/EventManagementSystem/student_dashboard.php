<?php
session_start();
require 'db_connection.php'; // Database connection

if (!isset($_SESSION['student'])) {
    header('Location: student_login.php');
    exit();
}

// Fetch events
$events_query = "SELECT * FROM events";
$events_result = $conn->query($events_query);

// Fetch chat messages
$branch = $_SESSION['branch']; // Assuming the branch is stored in the session
$chat_query = $conn->prepare("SELECT m.message_text, m.message_date, a.username FROM messages m JOIN admin a ON m.sender_id = a.admin_id WHERE m.receiver_branch = ?");
$chat_query->bind_param("s", $branch);
$chat_query->execute();
$chat_result = $chat_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Welcome to the Student Dashboard!</h1>
        <h2>Your Events</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Event Name</th>
                    <th>Description</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($event = $events_result->fetch_assoc()) : ?>
                    <tr>
                        <td><?php echo $event['event_name']; ?></td>
                        <td><?php echo $event['event_description']; ?></td>
                        <td><?php echo $event['event_date']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <h2>Your Chat Messages</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>Message</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($chat = $chat_result->fetch_assoc()) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($chat['message_text']); ?></td>
                        <td><?php echo $chat['message_date']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>
</body>
</html>
