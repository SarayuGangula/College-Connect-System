<?php
session_start();
require 'db_connection.php';

// Ensure required fields are present
if (!isset($_POST['message'], $_POST['branch'], $_POST['senderId'], $_POST['userType'])) {
    echo json_encode(["error" => "Invalid input!"]);
    exit();
}

$messageText = $_POST['message'];
$branch = $_POST['branch'];
$senderId = $_POST['senderId'];
$userTypeSender = $_POST['userType']; // 'admin' or 'student'

// Fetch group_id based on branch
$query = "SELECT group_id FROM groups WHERE branch_name = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $branch);
$stmt->execute();
$result = $stmt->get_result();
$group = $result->fetch_assoc();

if ($group) {
    $group_id = $group['group_id'];

    // Now use this group_id to insert messages
    $insertQuery = "INSERT INTO messages (sender_id, user_type_sender, group_id, message_text, timestamp) VALUES (?, ?, ?, ?, NOW())";
    $insertStmt = $conn->prepare($insertQuery);
    $insertStmt->bind_param("issi", $senderId, $userTypeSender, $group_id, $messageText);
    
    if ($insertStmt->execute()) {
        echo json_encode(["success" => "Message sent successfully!"]);
    } else {
        echo json_encode(["error" => "Failed to send message."]);
    }
} else {
    echo json_encode(["error" => "No group found for this branch!"]);
}
?>
