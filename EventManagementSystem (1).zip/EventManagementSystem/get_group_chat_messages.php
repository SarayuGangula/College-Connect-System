<?php
session_start();
require 'db_connection.php';

// Ensure group ID is provided
if (!isset($_POST['group_id'])) {
    echo json_encode(["error" => "No group specified!"]);
    exit();
}

$group_id = $_POST['group_id'];

// Fetch messages for the specified group
$query = "SELECT * FROM messages WHERE group_id = ? ORDER BY timestamp ASC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $group_id);
$stmt->execute();
$result = $stmt->get_result();

$messages = [];

// Fetch messages and prepare the response
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $senderType = $row['user_type_sender'];
        $senderName = ($senderType === 'student') ? getStudentName($row['sender_id'], $conn) : getAdminName($row['sender_id'], $conn);
        
        // Prepare message for output
        $messages[] = [
            'sender' => htmlspecialchars($senderName, ENT_QUOTES),
            'message' => htmlspecialchars($row['message_text'], ENT_QUOTES),
            'timestamp' => $row['timestamp']
        ];
    }
    echo json_encode($messages); // Return messages as JSON
} else {
    echo json_encode(["message" => "No messages yet for this group."]);
}
exit(); // Ensure the script exits after outputting JSON

// Helper functions
function getStudentName($studentId, $conn) {
    $query = "SELECT name FROM students WHERE student_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $studentId);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
    return $student['name'];
}

function getAdminName($adminId, $conn) {
    $query = "SELECT username FROM admin WHERE admin_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $adminId);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();
    return $admin['username'];
}
?>
