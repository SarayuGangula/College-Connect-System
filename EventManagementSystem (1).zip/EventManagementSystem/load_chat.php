<?php
session_start();
require 'db_connection.php';

// Safety checks
if (!isset($_SESSION['admin_id'])) {
    echo "Access Denied";
    exit();
}

$admin_id = $_SESSION['admin_id'];
$student_id = $_POST['student_id'] ?? null;

// Fetch messages from database
$query = "SELECT m.*, a.username AS admin_name, s.name AS student_name FROM messages m
          JOIN admin a ON m.sender_id = a.admin_id
          JOIN students s ON m.receiver_id = s.student_id
          WHERE (sender_id = ? AND receiver_id = ?) OR (receiver_id = ? AND sender_id = ?)
          ORDER BY timestamp DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("iiii", $admin_id, $student_id, $admin_id, $student_id);
$stmt->execute();
$result = $stmt->get_result();

$chat = [];
while ($row = $result->fetch_assoc()) {
    $chat[] = $row;
}

echo json_encode($chat);
?>