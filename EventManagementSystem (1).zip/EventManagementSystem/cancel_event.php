<?php
session_start(); // Start the session
require 'db_connection.php'; // Database connection
// Assuming this code block is in cancel_event.php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cancel_event'])) {
    $event_id = $_POST['event_id'];

    // Assuming $conn is your database connection object
    $sql = "UPDATE events SET status = 'Cancelled' WHERE event_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $event_id);
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error"; // Optionally, add further detail about the failure
    }

    $stmt->close();
    $conn->close();
}
?>