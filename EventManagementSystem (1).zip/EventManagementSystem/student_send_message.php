<?php
session_start();
require 'db_connection.php'; // Replace with your actual database connection file

// Check if the student is logged in
if (!isset($_SESSION['student_id'])) {
    echo json_encode(["status" => "error", "message" => "Student not logged in"]);
    exit;
}

// Retrieve the message and admin ID from POST request
$messageText = $_POST['message'] ?? '';
$adminId = $_POST['adminId'] ?? null; // Ensure this matches with your JavaScript
$studentId = $_POST['studentId'] ?? null;

// Validate input
if (!$messageText) {
    echo json_encode(["status" => "error", "message" => "Message text is empty"]);
    exit;
}

if (!$adminId) {
    echo json_encode(["status" => "error", "message" => "Admin ID is missing"]);
    exit;
}

// Prepare the SQL query to insert the message
$query = "INSERT INTO messages (sender_id, receiver_id, message_text, timestamp) VALUES (?, ?, ?, NOW())";
$stmt = $conn->prepare($query);

// Check for errors during query preparation
if (!$stmt) {
    echo json_encode([
        "status" => "error",
        "message" => "Failed to prepare statement: " . $conn->error
    ]);
    exit;
}

// Bind the parameters and execute the statement
$stmt->bind_param("iis", $studentId, $adminId, $messageText);
if (!$stmt->execute()) {
    echo json_encode([
        "status" => "error",
        "message" => "Failed to execute statement: " . $stmt->error
    ]);
    exit;
}

// Return success response
echo json_encode(["status" => "success"]);

// Clean up
$stmt->close();
$conn->close();
?>