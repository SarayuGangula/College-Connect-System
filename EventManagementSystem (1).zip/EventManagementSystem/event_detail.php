<?php
session_start();
require 'db_connection.php'; // Database connection

// Check if event ID is set in the URL
if (!isset($_GET['id'])) {
    echo "Event ID not provided.";
    exit();
}

$event_id = (int)$_GET['id']; // Get the event ID from the URL

// Fetch event details from the database
$query = "SELECT event_name, description, event_from_date, event_to_date, branch, status, winners, pic1 FROM events WHERE event_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $event_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Event not found.";
    exit();
}

$event = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($event['event_name']); ?> - Event Details</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #e9ecef;
        }
        .event-detail {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px;
        }
        .event-image {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }
    </style>
</head>
<body>

<header class="d-flex justify-content-between align-items-center p-3 header">
    <img src="images/logo.png" alt="Logo" height="50">
    <a href="events.php" class="btn btn-secondary">Back to Events</a>
</header>

<main class="container mt-5">
    <div class="event-detail">
        <h1><?php echo htmlspecialchars($event['event_name']); ?></h1>
        <img src="data:image/jpeg;base64,<?php echo base64_encode($event['pic1']); ?>" alt="Event Image" class="event-image">
        <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($event['description'])); ?></p>
        <p><strong>Date:</strong> <?php echo htmlspecialchars($event['event_from_date']); ?> to <?php echo htmlspecialchars($event['event_to_date']); ?></p>
        <p><strong>Branch:</strong> <?php echo htmlspecialchars($event['branch']); ?></p>
        <p><strong>Status:</strong> <?php echo htmlspecialchars($event['status']); ?></p>
        <p><strong>Winners:</strong> <?php echo htmlspecialchars($event['winners']); ?></p>
    </div>
</main>

<footer class="text-center mt-4">
    <p>&copy; 2024 Event Management System. All rights reserved.</p>
</footer>

</body>
</html>
