<?php
// Assume student_id is passed as a GET parameter.
$studentId = $_GET['student_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Chat with Student</title>
<style>
    #chatBox {
        height: 500px;
        overflow-y: auto;
        border: 1px solid #ccc;
        padding: 10px;
    }
    #message {
        width: 100%;
        height: 100px;
        padding: 5px;
    }
</style>
</head>
<body>
<div id="chatBox">
    <!-- Messages will be loaded here -->
</div>
<textarea id="message"></textarea>
<button onclick="sendMessage(<?= $studentId; ?>);">Send</button>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
// Load existing messages and keep updating every 5 seconds
function loadMessages(studentId) {
    $.ajax({
        url: 'get_messages.php',
        type: 'POST',
        data: { student_id: studentId },
        success: function(data) {
            $('#chatBox').html(data);
            setTimeout(loadMessages, 5000, studentId); // Reload every 5 seconds
        }
    });
}

// Send a new message
function sendMessage(studentId) {
    var message = $('#message').val();
    $.ajax({
        url: 'send_message.php',
        type: 'POST',
        data: {
            student_id: studentId,
            message: message
        },
        success: function(data) {
            $('#message').val(''); // Clear the input area
            loadMessages(studentId);
        }
    });
}

// Initial call to load messages
loadMessages(<?= $studentId; ?>);
</script>
</body>
</html>